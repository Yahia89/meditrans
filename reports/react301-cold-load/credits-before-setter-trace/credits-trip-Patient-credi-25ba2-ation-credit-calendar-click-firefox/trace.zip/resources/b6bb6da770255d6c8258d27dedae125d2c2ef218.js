import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/patient-details-page.tsx");const useState = __vite__cjsImport0_react["useState"]; const useMemo = __vite__cjsImport0_react["useMemo"];const _jsxDEV = __vite__cjsImport21_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport21_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=50b8a1ac";
import { useRouteQueryState as useQueryState } from "/src/router/navigation.ts";
import { ArrowLeft, Calendar, Phone, Mail, MapPin, Loader2, Pencil, ShieldAlert, FileText, Briefcase, CreditCard, Trash, ChevronLeft, ChevronRight, ClipboardCheck, Clock, XCircle, CheckCircle2, History, MinusCircle, Printer } from "/node_modules/.vite/deps/lucide-react.js?v=50b8a1ac";
import { CaretLeft, CaretRight, CalendarBlank, Funnel, Coins, FilePdf, IdentificationCard, Files, MapTrifold } from "/node_modules/.vite/deps/@phosphor-icons_react.js?v=50b8a1ac";
import { useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=50b8a1ac";
import { supabase } from "/src/lib/supabase.ts";
import { Button } from "/src/components/ui/button.tsx";
import { cn, formatPhoneNumber } from "/src/lib/utils.ts";
import { usePermissions } from "/src/hooks/usePermissions.ts";
import { PatientForm } from "/src/components/forms/patient-form.tsx";
import { DocumentManager } from "/src/components/document-manager.tsx";
import { DeleteConfirmationDialog } from "/src/components/ui/delete-confirmation-dialog.tsx";
import { useOnboarding } from "/src/contexts/OnboardingContext.tsx";
import { PatientCreditTab } from "/src/components/credits/PatientCreditTab.tsx";
import { useAuth } from "/src/contexts/auth-context.tsx";
import { useOrganization } from "/src/contexts/OrganizationContext.tsx";
import { PatientSummaryTab } from "/src/components/summary/PatientSummaryTab.tsx";
import { getActiveTimezone, formatInUserTimezone, parseZonedTime } from "/src/lib/timezone.ts";
import { generateProfilePDF } from "/src/utils/profile-pdf-generator.ts";
import { useCanManageUserAccess } from "/src/hooks/useCanManageUserAccess.ts";
import { AccessStatusBadge, UserAccessToggleButton } from "/src/components/user-access-control.tsx";
var _jsxFileName = "/Users/yahiaalhejoj/meditrans/src/components/patient-details-page.tsx";
import __vite__cjsImport21_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=50b8a1ac";
var _s = $RefreshSig$();
const statusColors = {
	pending: "bg-slate-100 text-slate-700 border-slate-200",
	assigned: "bg-blue-50 text-blue-700 border-blue-100",
	accepted: "bg-indigo-50 text-indigo-700 border-indigo-100",
	en_route: "bg-sky-50 text-sky-700 border-sky-100",
	arrived: "bg-amber-50 text-amber-700 border-amber-100",
	in_progress: "bg-blue-100 text-blue-800 border-blue-200",
	completed: "bg-emerald-50 text-emerald-700 border-emerald-100",
	cancelled: "bg-red-50 text-red-700 border-red-100",
	no_show: "bg-orange-50 text-orange-700 border-orange-100",
	waiting: "bg-amber-100 text-amber-800 border-amber-200",
	loaded: "bg-purple-50 text-purple-700 border-purple-100",
	in_pickup_circle: "bg-cyan-50 text-cyan-700 border-cyan-100",
	in_dropoff_circle: "bg-pink-50 text-pink-700 border-pink-100"
};
function formatDate(dateStr, timezone = "UTC") {
	if (!dateStr) return "Not specified";
	// Handle YYYY-MM-DD specifically (Birthdays, etc)
	if (dateStr.length === 10 && dateStr.includes("-") && !dateStr.includes("T")) {
		return formatInUserTimezone(dateStr, "UTC", "MMMM d, yyyy");
	}
	return formatInUserTimezone(dateStr, timezone, "MMMM d, yyyy");
}
const TRIPS_PER_PAGE = 6;
export function PatientDetailsPage({ id, onBack, onTripClick }) {
	_s();
	const [activeTab, setActiveTab] = useQueryState("section", {
		defaultValue: "overview",
		parse: (value) => value || "overview"
	});
	const [isEditing, setIsEditing] = useState(false);
	const [showDeleteDialog, setShowDeleteDialog] = useState(false);
	const [isDeleting, setIsDeleting] = useState(false);
	const { profile } = useAuth();
	const { currentOrganization } = useOrganization();
	const { canEditPatients, canDeletePatients } = usePermissions();
	const { isDemoMode } = useOnboarding();
	const queryClient = useQueryClient();
	const canManageUserAccess = useCanManageUserAccess();
	const activeTimezone = useMemo(() => getActiveTimezone(profile, currentOrganization), [profile, currentOrganization]);
	// Trip history filtering and pagination state
	const [tripMonth, setTripMonth] = useState(() => {
		const now = new Date();
		return new Date(now.getFullYear(), now.getMonth(), 1);
	});
	const [tripPage, setTripPage] = useState(1);
	const [tripStatusFilter, setTripStatusFilter] = useState("all");
	const [selectedTripDate, setSelectedTripDate] = useQueryState("date", {
		parse: (v) => v ? new Date(v) : null,
		serialize: (v) => v?.toISOString() ?? ""
	});
	const canManagePatients = canEditPatients || canDeletePatients;
	// Fetch patient data
	const { data: patient, isLoading: isLoadingPatient } = useQuery({
		queryKey: ["patient", id],
		queryFn: async () => {
			const { data, error } = await supabase.from("patients").select("*").eq("id", id).single();
			if (error) throw error;
			return data;
		},
		enabled: !!id
	});
	// Fetch SAL history
	const { data: salHistory = [] } = useQuery({
		queryKey: ["sal-history", id],
		queryFn: async () => {
			const { data, error } = await supabase.from("patient_sal_history").select("*").eq("patient_id", id).order("created_at", { ascending: false });
			if (error) throw error;
			return data;
		},
		enabled: !!id
	});
	// Fetch all trips for this patient
	const { data: allTrips = [], isLoading: isLoadingTrips } = useQuery({
		queryKey: ["patient-trips", id],
		queryFn: async () => {
			const { data, error } = await supabase.from("trips").select(`
          *,
          driver:drivers(id, full_name, phone, vehicle_info)
        `).eq("patient_id", id).order("pickup_time", { ascending: false });
			if (error) throw error;
			return data;
		},
		enabled: !!id
	});
	// Fetch document count
	const { data: docCount = 0 } = useQuery({
		queryKey: ["patient-docs-count", id],
		queryFn: async () => {
			const { count, error } = await supabase.from("org_uploads").select("*", {
				count: "exact",
				head: true
			}).eq("purpose", "patient_document").eq("notes", id);
			if (error) throw error;
			return count || 0;
		}
	});
	// Filter trips by month and status
	const filteredTrips = useMemo(() => {
		// If a specific date is selected, filter by that day
		if (selectedTripDate) {
			const targetDateStr = formatInUserTimezone(selectedTripDate, activeTimezone, "yyyy-MM-dd");
			return allTrips.filter((trip) => {
				const tripDateStr = formatInUserTimezone(trip.pickup_time, activeTimezone, "yyyy-MM-dd");
				const matchesStatus = tripStatusFilter === "all" || trip.status === tripStatusFilter;
				return tripDateStr === targetDateStr && matchesStatus;
			});
		}
		// Otherwise show all trips for the selected month
		const monthStr = formatInUserTimezone(tripMonth, activeTimezone, "yyyy-MM");
		const startOfMonthUTC = parseZonedTime(`${monthStr}-01`, "00:00", activeTimezone);
		// Get last day of month
		const year = parseInt(monthStr.split("-")[0]);
		const month = parseInt(monthStr.split("-")[1]);
		const lastDay = new Date(year, month, 0).getDate();
		const endOfMonthUTC = parseZonedTime(`${monthStr}-${lastDay}`, "23:59:59", activeTimezone);
		return allTrips.filter((trip) => {
			const tripDate = new Date(trip.pickup_time);
			const inMonth = tripDate >= startOfMonthUTC && tripDate <= endOfMonthUTC;
			const matchesStatus = tripStatusFilter === "all" || trip.status === tripStatusFilter;
			return inMonth && matchesStatus;
		});
	}, [
		allTrips,
		tripMonth,
		tripStatusFilter,
		selectedTripDate,
		activeTimezone
	]);
	// Paginate filtered trips
	const paginatedTrips = useMemo(() => {
		const start = (tripPage - 1) * TRIPS_PER_PAGE;
		return filteredTrips.slice(start, start + TRIPS_PER_PAGE);
	}, [filteredTrips, tripPage]);
	const totalTripPages = Math.ceil(filteredTrips.length / TRIPS_PER_PAGE);
	// Reset to page 1 when filters change
	useMemo(() => {
		setTripPage(1);
	}, [
		tripMonth,
		tripStatusFilter,
		selectedTripDate
	]);
	const goToPrevMonth = () => {
		setTripMonth((prev) => new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
	};
	const goToNextMonth = () => {
		setTripMonth((prev) => new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
	};
	const goToCurrentMonth = () => {
		const now = new Date();
		setTripMonth(new Date(now.getFullYear(), now.getMonth(), 1));
	};
	const handleDelete = async () => {
		if (isDemoMode) return;
		setIsDeleting(true);
		try {
			const { error } = await supabase.from("patients").delete().eq("id", id);
			if (error) throw error;
			queryClient.invalidateQueries({ queryKey: ["patients"] });
			queryClient.invalidateQueries({ queryKey: [
				"trips",
				"directory-counts",
				currentOrganization?.id
			] });
			onBack();
		} catch (err) {
			console.error("Failed to delete patient:", err);
		} finally {
			setIsDeleting(false);
		}
	};
	if (isLoadingPatient) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "flex h-96 items-center justify-center",
			children: /* @__PURE__ */ _jsxDEV(Loader2, { className: "h-8 w-8 animate-spin text-slate-400" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 356,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 355,
			columnNumber: 7
		}, this);
	}
	if (!patient) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "text-center py-12",
			children: [/* @__PURE__ */ _jsxDEV("p", {
				className: "text-slate-500",
				children: "Patient not found"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 364,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(Button, {
				variant: "link",
				onClick: onBack,
				children: "Go back to patients"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 365,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 363,
			columnNumber: 7
		}, this);
	}
	const accessDisabled = patient.disabled === true;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col gap-4 2xl:flex-row 2xl:items-center 2xl:justify-between",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex min-w-0 items-center gap-4",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: onBack,
						className: "p-2 rounded-lg hover:bg-slate-100 transition-colors",
						children: /* @__PURE__ */ _jsxDEV(ArrowLeft, {
							size: 20,
							className: "text-slate-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 383,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 379,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ _jsxDEV("h1", {
							className: "min-w-0 break-words text-2xl font-semibold text-slate-900",
							children: patient.full_name
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 386,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap items-center gap-2 mt-1",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700",
									children: "Client Profile"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 390,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(AccessStatusBadge, { disabled: accessDisabled }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 393,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-slate-500",
									children: ["ID: ", patient.id.substring(0, 8)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 394,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 389,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 385,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 378,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid w-full grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3 2xl:flex 2xl:w-auto 2xl:flex-wrap 2xl:justify-end",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						variant: "outline",
						onClick: () => generateProfilePDF("patient", patient, currentOrganization?.name || "", activeTimezone),
						className: "w-full items-center justify-center gap-2 rounded-xl 2xl:w-auto",
						children: [/* @__PURE__ */ _jsxDEV(Printer, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 414,
							columnNumber: 13
						}, this), "Print Out"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 402,
						columnNumber: 11
					}, this), (canManagePatients || canManageUserAccess) && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
						canEditPatients && /* @__PURE__ */ _jsxDEV(Button, {
							variant: "outline",
							onClick: () => setIsEditing(true),
							className: "w-full items-center justify-center gap-2 rounded-xl 2xl:w-auto",
							children: [/* @__PURE__ */ _jsxDEV(Pencil, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 425,
								columnNumber: 19
							}, this), "Edit Details"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 420,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV(UserAccessToggleButton, {
							targetType: "patient",
							recordId: patient.id,
							subjectName: patient.full_name,
							disabled: accessDisabled,
							canManage: canManageUserAccess,
							isDemoMode,
							onSuccess: () => {
								queryClient.invalidateQueries({ queryKey: ["patient", id] });
								queryClient.invalidateQueries({ queryKey: ["patients", currentOrganization?.id] });
							}
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 429,
							columnNumber: 15
						}, this),
						canDeletePatients && /* @__PURE__ */ _jsxDEV(Button, {
							variant: "outline",
							onClick: () => setShowDeleteDialog(true),
							disabled: isDemoMode,
							className: "w-full items-center justify-center gap-2 rounded-xl text-red-600 border-red-100 hover:bg-red-50 hover:text-red-700 2xl:w-auto",
							children: [/* @__PURE__ */ _jsxDEV(Trash, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 450,
								columnNumber: 19
							}, this), "Delete Patient"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 444,
							columnNumber: 17
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 418,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 401,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 377,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "border-b-0 sm:border-b border-slate-200 -mx-4 px-4 sm:mx-0 sm:px-0",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap items-center gap-2 sm:gap-0",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("overview"),
							className: cn("px-4 py-2 sm:py-3 text-sm font-medium transition-all flex items-center gap-2 whitespace-nowrap rounded-xl sm:rounded-none sm:border-b-2", activeTab === "overview" ? "bg-[#3D5A3D]/10 text-[#3D5A3D] sm:bg-transparent sm:border-[#3D5A3D]" : "text-slate-500 hover:text-slate-700 hover:bg-slate-100 sm:hover:bg-transparent sm:border-transparent sm:hover:border-slate-300"),
							children: [/* @__PURE__ */ _jsxDEV(IdentificationCard, {
								size: 16,
								weight: "duotone",
								className: "text-[#3D5A3D]"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 471,
								columnNumber: 13
							}, this), "Overview"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 462,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("documents"),
							className: cn("px-4 py-2 sm:py-3 text-sm font-medium transition-all flex items-center gap-2 whitespace-nowrap rounded-xl sm:rounded-none sm:border-b-2", activeTab === "documents" ? "bg-[#3D5A3D]/10 text-[#3D5A3D] sm:bg-transparent sm:border-[#3D5A3D]" : "text-slate-500 hover:text-slate-700 hover:bg-slate-100 sm:hover:bg-transparent sm:border-transparent sm:hover:border-slate-300"),
							children: [
								/* @__PURE__ */ _jsxDEV(Files, {
									size: 16,
									weight: "duotone",
									className: "text-[#3D5A3D]"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 487,
									columnNumber: 13
								}, this),
								"Documents",
								/* @__PURE__ */ _jsxDEV("span", {
									className: cn("px-2 py-0.5 rounded-full text-[10px] font-bold", activeTab === "documents" ? "bg-[#3D5A3D] text-white" : "bg-slate-100 text-slate-500"),
									children: docCount
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 489,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 478,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("trips"),
							className: cn("px-4 py-2 sm:py-3 text-sm font-medium transition-all flex items-center gap-2 whitespace-nowrap rounded-xl sm:rounded-none sm:border-b-2", activeTab === "trips" ? "bg-[#3D5A3D]/10 text-[#3D5A3D] sm:bg-transparent sm:border-[#3D5A3D]" : "text-slate-500 hover:text-slate-700 hover:bg-slate-100 sm:hover:bg-transparent sm:border-transparent sm:hover:border-slate-300"),
							children: [
								/* @__PURE__ */ _jsxDEV(MapTrifold, {
									size: 16,
									weight: "duotone",
									className: "text-[#3D5A3D]"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 509,
									columnNumber: 13
								}, this),
								"Trip History",
								/* @__PURE__ */ _jsxDEV("span", {
									className: cn("px-2 py-0.5 rounded-full text-[10px] font-bold", activeTab === "trips" ? "bg-[#3D5A3D] text-white" : "bg-slate-100 text-slate-500"),
									children: allTrips.length
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 511,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 500,
							columnNumber: 11
						}, this),
						(canManagePatients || patient.monthly_credit) && /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("credits"),
							className: cn("px-4 py-2 sm:py-3 text-sm font-medium transition-all flex items-center gap-2 whitespace-nowrap rounded-xl sm:rounded-none sm:border-b-2", activeTab === "credits" ? "bg-[#3D5A3D]/10 text-[#3D5A3D] sm:bg-transparent sm:border-[#3D5A3D]" : "text-slate-500 hover:text-slate-700 hover:bg-slate-100 sm:hover:bg-transparent sm:border-transparent sm:hover:border-slate-300"),
							children: [
								/* @__PURE__ */ _jsxDEV(Coins, {
									weight: "duotone",
									size: 16,
									className: "text-[#3D5A3D]"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 533,
									columnNumber: 15
								}, this),
								"Credits",
								patient.monthly_credit && /* @__PURE__ */ _jsxDEV("span", {
									className: cn("px-2 py-0.5 rounded-full text-[10px] font-bold", activeTab === "credits" ? "bg-[#3D5A3D] text-white" : "bg-emerald-100 text-emerald-700"),
									children: ["$", patient.monthly_credit.toLocaleString()]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 536,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 524,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("summary"),
							className: cn("px-4 py-2 sm:py-3 text-sm font-medium transition-all flex items-center gap-2 whitespace-nowrap rounded-xl sm:rounded-none sm:border-b-2", activeTab === "summary" ? "bg-[#3D5A3D]/10 text-[#3D5A3D] sm:bg-transparent sm:border-[#3D5A3D]" : "text-slate-500 hover:text-slate-700 hover:bg-slate-100 sm:hover:bg-transparent sm:border-transparent sm:hover:border-slate-300"),
							children: [/* @__PURE__ */ _jsxDEV(FilePdf, {
								size: 16,
								weight: "duotone",
								className: "text-[#3D5A3D]"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 558,
								columnNumber: 13
							}, this), "Trips summary"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 549,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 461,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 460,
				columnNumber: 7
			}, this),
			activeTab === "overview" && /* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-3 gap-6",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-2 space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white rounded-2xl border border-slate-200 p-6 shadow-sm",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-lg font-semibold text-slate-900 mb-6",
								children: "Personal Information"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 571,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-8",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-4",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-start gap-3",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "p-2 bg-slate-50 rounded-lg",
												children: /* @__PURE__ */ _jsxDEV(Calendar, { className: "w-5 h-5 text-slate-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 578,
													columnNumber: 23
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 577,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "text-sm font-medium text-slate-500 uppercase tracking-wider",
												children: "Date of Birth"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 581,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-slate-900 mt-0.5",
												children: formatDate(patient.date_of_birth, activeTimezone)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 584,
												columnNumber: 23
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 580,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 576,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-start gap-3",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "p-2 bg-slate-50 rounded-lg",
												children: /* @__PURE__ */ _jsxDEV(Phone, { className: "w-5 h-5 text-slate-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 591,
													columnNumber: 23
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 590,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "text-sm font-medium text-slate-500 uppercase tracking-wider",
												children: "Phone Number"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 594,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-slate-900 mt-0.5",
												children: patient.phone ? formatPhoneNumber(patient.phone) : "Not specified"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 597,
												columnNumber: 23
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 593,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 589,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-start gap-3",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "p-2 bg-slate-50 rounded-lg",
												children: /* @__PURE__ */ _jsxDEV(MapPin, { className: "w-5 h-5 text-slate-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 606,
													columnNumber: 23
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 605,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "text-sm font-medium text-slate-500 uppercase tracking-wider",
												children: "Primary Address"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 609,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-slate-900 mt-0.5",
												children: patient.primary_address || "Not specified"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 612,
												columnNumber: 23
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 608,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 604,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 575,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-4",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start gap-3",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "p-2 bg-slate-50 rounded-lg",
											children: /* @__PURE__ */ _jsxDEV(Mail, { className: "w-5 h-5 text-slate-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 621,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 620,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm font-medium text-slate-500 uppercase tracking-wider",
											children: "Email Address"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 624,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-900 mt-0.5",
											children: patient.email || "Not specified"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 627,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 623,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 619,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start gap-3",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "p-2 bg-slate-50 rounded-lg",
											children: /* @__PURE__ */ _jsxDEV(MapPin, { className: "w-5 h-5 text-slate-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 634,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 633,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm font-medium text-slate-500 uppercase tracking-wider",
											children: "County"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 637,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-900 mt-0.5",
											children: patient.county || "Not specified"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 640,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 636,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 632,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 618,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 574,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 570,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white rounded-2xl border border-slate-200 p-6 shadow-sm",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-lg font-semibold text-slate-900 mb-6",
								children: "Service & Referral"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 651,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-8",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-4",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm font-medium text-slate-500 uppercase tracking-wider",
											children: "Service Type"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 657,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-900 mt-1 font-medium",
											children: patient.service_type || "Not specified"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 660,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 656,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm font-medium text-slate-500 uppercase tracking-wider",
											children: "Waiver Type"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 665,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-900 mt-1",
											children: patient.waiver_type || "Not specified"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 668,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 664,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm font-medium text-slate-500 uppercase tracking-wider",
											children: "Vehicle Need"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 673,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-900 mt-1",
											children: patient.vehicle_type_need || "Not specified"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 676,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 672,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 655,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-4",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm font-medium text-slate-500 uppercase tracking-wider",
										children: "Referred By"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 683,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-slate-900 mt-1",
										children: patient.referral_by || "Not specified"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 686,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 682,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm font-medium text-slate-500 uppercase tracking-wider",
										children: "Referral Period"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 691,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-slate-900 mt-1",
										children: [
											patient.referral_date ? formatDate(patient.referral_date, activeTimezone) : "Start",
											/* @__PURE__ */ _jsxDEV("span", {
												className: "mx-2 text-slate-400",
												children: "→"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 698,
												columnNumber: 23
											}, this),
											patient.referral_expiration_date ? formatDate(patient.referral_expiration_date, activeTimezone) : "End"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 694,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 690,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 681,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 654,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 650,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 md:grid-cols-2 gap-6",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white rounded-2xl border border-slate-200 p-6 shadow-sm",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-semibold text-slate-900 uppercase tracking-wider mb-4 flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV(Briefcase, { className: "w-4 h-4 text-slate-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 715,
										columnNumber: 19
									}, this), "Case Management"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 714,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-3",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-500",
											children: "Manager Name"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 720,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm font-medium text-slate-900",
											children: patient.case_manager || "None assigned"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 721,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 719,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-500",
											children: "Contact Number"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 726,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm font-medium text-slate-900",
											children: patient.case_manager_phone ? formatPhoneNumber(patient.case_manager_phone) : "N/A"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 727,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 725,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-500",
											children: "Email"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 734,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm font-medium text-slate-900",
											children: patient.case_manager_email || "N/A"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 735,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 733,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 718,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 713,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white rounded-2xl border border-slate-200 p-6 shadow-sm",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-semibold text-slate-900 uppercase tracking-wider mb-4 flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV(CreditCard, { className: "w-4 h-4 text-slate-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 743,
										columnNumber: 19
									}, this), "Billing Details"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 742,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-3",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-500",
											children: "Monthly Credit"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 748,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm font-bold text-emerald-600",
											children: patient.monthly_credit ? `$${patient.monthly_credit.toFixed(2)}` : "$0.00"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 749,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 747,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-500",
											children: "Credit Used For"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 756,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm text-slate-600",
											children: patient.credit_used_for || "General use"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 757,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 755,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-500",
											children: "Medicaid ID"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 762,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm font-medium text-slate-900 font-mono",
											children: patient.medicaid_id || "N/A"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 763,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 761,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 746,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 741,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 712,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white rounded-2xl border border-slate-200 p-6 shadow-sm",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between mb-6",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-lg font-semibold text-slate-900",
									children: "Medical Notes"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 774,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV(FileText, { className: "w-5 h-5 text-slate-300" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 777,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 773,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "p-4 bg-slate-50 rounded-xl border border-slate-100 min-h-[120px]",
								children: patient.notes ? /* @__PURE__ */ _jsxDEV("p", {
									className: "text-slate-600 leading-relaxed whitespace-pre-wrap",
									children: patient.notes
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 781,
									columnNumber: 19
								}, this) : /* @__PURE__ */ _jsxDEV("p", {
									className: "text-slate-400 italic",
									children: "No notes recorded for this patient."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 785,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 779,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 772,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 568,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white rounded-2xl border border-slate-200 p-6 shadow-sm",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-sm font-semibold text-slate-900 uppercase tracking-wider mb-4",
								children: "Patient Status"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 796,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between py-2 border-b border-slate-50",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-sm text-slate-500",
											children: "Total Trips"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 801,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-sm font-semibold text-slate-900",
											children: allTrips.length
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 802,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 800,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between py-2 border-b border-slate-50",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-sm text-slate-500",
											children: "Last Transport"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 807,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-sm text-slate-900",
											children: allTrips.length > 0 ? formatDate(allTrips[0].pickup_time, activeTimezone) : "Never"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 808,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 806,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between py-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-sm text-slate-500",
											children: "Added On"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 815,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-sm text-slate-900",
											children: formatDate(patient.created_at, activeTimezone)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 816,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 814,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 799,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 795,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: cn("rounded-2xl border p-6 shadow-sm", patient.sal_status === "approved" && "bg-emerald-50/50 border-emerald-200", patient.sal_status === "pending" && "bg-amber-50/50 border-amber-200", patient.sal_status === "expired" && "bg-red-50/50 border-red-200", !patient.sal_status && "bg-white border-slate-200"),
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-sm font-semibold text-slate-900 uppercase tracking-wider mb-4 flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(ClipboardCheck, { className: "w-4 h-4 text-slate-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 837,
									columnNumber: 17
								}, this), "SAL Status"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 836,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [
										patient.sal_status === "approved" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center",
											children: /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-600" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 847,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 846,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm font-semibold text-emerald-700",
											children: "Approved"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 850,
											columnNumber: 25
										}, this), patient.sal_effective_date && /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-500",
											children: [
												formatDate(patient.sal_effective_date, activeTimezone),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "mx-1",
													children: "→"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 859,
													columnNumber: 29
												}, this),
												patient.sal_through_date ? formatDate(patient.sal_through_date, activeTimezone) : "No end date"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 854,
											columnNumber: 27
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 849,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 845,
											columnNumber: 21
										}, this),
										patient.sal_status === "pending" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center",
											children: /* @__PURE__ */ _jsxDEV(Clock, { className: "w-4 h-4 text-amber-600" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 874,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 873,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm font-semibold text-amber-700",
											children: "Pending"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 877,
											columnNumber: 25
										}, this), patient.sal_pending_reason && /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-500 line-clamp-2",
											children: patient.sal_pending_reason
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 881,
											columnNumber: 27
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 876,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 872,
											columnNumber: 21
										}, this),
										patient.sal_status === "expired" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "w-8 h-8 rounded-full bg-red-100 flex items-center justify-center",
											children: /* @__PURE__ */ _jsxDEV(XCircle, { className: "w-4 h-4 text-red-500" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 891,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 890,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm font-semibold text-red-600",
											children: "Expired"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 894,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-500",
											children: "Needs recertification"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 897,
											columnNumber: 25
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 893,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 889,
											columnNumber: 21
										}, this),
										patient.sal_status === "n/a" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center",
											children: /* @__PURE__ */ _jsxDEV(MinusCircle, { className: "w-4 h-4 text-slate-500" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 906,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 905,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm font-semibold text-slate-600",
											children: "N/A"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 909,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-500",
											children: "Not applicable to this client"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 912,
											columnNumber: 25
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 908,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 904,
											columnNumber: 21
										}, this),
										!patient.sal_status && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center",
											children: /* @__PURE__ */ _jsxDEV(ClipboardCheck, { className: "w-4 h-4 text-slate-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 921,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 920,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm font-medium text-slate-500",
											children: "Not Set"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 924,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-400",
											children: "No SAL status recorded"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 927,
											columnNumber: 25
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 923,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 919,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 843,
									columnNumber: 17
								}, this), salHistory.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
									className: "border-t border-slate-100 pt-3 mt-3",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs font-medium text-slate-500 flex items-center gap-1.5 mb-2",
										children: [
											/* @__PURE__ */ _jsxDEV(History, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 939,
												columnNumber: 23
											}, this),
											"History (",
											salHistory.length,
											")"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 938,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1.5 max-h-[200px] overflow-y-auto",
										children: salHistory.map((entry) => /* @__PURE__ */ _jsxDEV("div", {
											className: cn(entry.status === "approved" && "bg-emerald-50/70", entry.status === "pending" && "bg-amber-50/70", entry.status === "expired" && "bg-red-50/70", entry.status === "n/a" && "bg-slate-50"),
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: cn("w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5", entry.status === "approved" && "bg-emerald-100", entry.status === "pending" && "bg-amber-100", entry.status === "expired" && "bg-red-100", entry.status === "n/a" && "bg-slate-200"),
												children: [
													entry.status === "approved" && /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-3 h-3 text-emerald-600" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 963,
														columnNumber: 31
													}, this),
													entry.status === "pending" && /* @__PURE__ */ _jsxDEV(Clock, { className: "w-3 h-3 text-amber-600" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 966,
														columnNumber: 31
													}, this),
													entry.status === "expired" && /* @__PURE__ */ _jsxDEV(XCircle, { className: "w-3 h-3 text-red-500" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 969,
														columnNumber: 31
													}, this),
													entry.status === "n/a" && /* @__PURE__ */ _jsxDEV(MinusCircle, { className: "w-3 h-3 text-slate-500" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 972,
														columnNumber: 31
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 953,
												columnNumber: 27
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex-1 min-w-0",
												children: [
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center justify-between gap-1",
														children: [/* @__PURE__ */ _jsxDEV("span", {
															className: cn("font-semibold capitalize", entry.status === "approved" && "text-emerald-700", entry.status === "pending" && "text-amber-700", entry.status === "expired" && "text-red-600", entry.status === "n/a" && "text-slate-600"),
															children: entry.status === "n/a" ? "N/A" : entry.status
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 977,
															columnNumber: 31
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "text-slate-400 shrink-0",
															children: new Date(entry.created_at).toLocaleDateString("en-US", {
																month: "short",
																day: "numeric",
																year: "2-digit"
															})
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 990,
															columnNumber: 31
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 976,
														columnNumber: 29
													}, this),
													entry.status === "approved" && entry.effective_date && /* @__PURE__ */ _jsxDEV("p", {
														className: "text-slate-500",
														children: [
															new Date(entry.effective_date + "T00:00:00").toLocaleDateString("en-US", {
																month: "short",
																day: "numeric"
															}),
															/* @__PURE__ */ _jsxDEV("span", {
																className: "mx-1",
																children: "→"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1010,
																columnNumber: 35
															}, this),
															entry.through_date ? new Date(entry.through_date + "T00:00:00").toLocaleDateString("en-US", {
																month: "short",
																day: "numeric"
															}) : "—"
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1003,
														columnNumber: 33
													}, this),
													entry.status === "pending" && entry.pending_reason && /* @__PURE__ */ _jsxDEV("p", {
														className: "text-slate-500 line-clamp-1",
														children: entry.pending_reason
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1023,
														columnNumber: 33
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 975,
												columnNumber: 27
											}, this)]
										}, entry.id, true, {
											fileName: _jsxFileName,
											lineNumber: 944,
											columnNumber: 25
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 942,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 937,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 842,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 824,
							columnNumber: 13
						}, this),
						!canManagePatients && /* @__PURE__ */ _jsxDEV("div", {
							className: "bg-amber-50 border border-amber-200 rounded-2xl p-6",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3 text-amber-800 mb-2",
								children: [/* @__PURE__ */ _jsxDEV(ShieldAlert, { size: 20 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1039,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "font-semibold",
									children: "View Only"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1040,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1038,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-sm text-amber-700 leading-relaxed",
								children: "You have view-only access to this patient's profile. Only administrators and owners can modify details or upload documents."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1042,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1037,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 794,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 566,
				columnNumber: 9
			}, this),
			activeTab === "documents" && /* @__PURE__ */ _jsxDEV(DocumentManager, {
				ownerId: id,
				purpose: "patient_document",
				source: "patients"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1054,
				columnNumber: 9
			}, this),
			activeTab === "trips" && /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-6",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white rounded-xl border border-slate-200 p-4",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4",
							children: [!selectedTripDate ? /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV(Button, {
										variant: "ghost",
										size: "sm",
										onClick: goToPrevMonth,
										className: "h-8 w-8 p-0",
										children: /* @__PURE__ */ _jsxDEV(CaretLeft, {
											size: 16,
											weight: "bold"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1075,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1069,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV(Button, {
										variant: "outline",
										size: "sm",
										onClick: goToCurrentMonth,
										className: "h-8 px-3 text-xs font-medium min-w-[140px]",
										children: [/* @__PURE__ */ _jsxDEV(CalendarBlank, {
											size: 14,
											weight: "duotone",
											className: "mr-2"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1083,
											columnNumber: 21
										}, this), formatInUserTimezone(tripMonth, activeTimezone, "MMMM yyyy")]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1077,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV(Button, {
										variant: "ghost",
										size: "sm",
										onClick: goToNextMonth,
										className: "h-8 w-8 p-0",
										children: /* @__PURE__ */ _jsxDEV(CaretRight, {
											size: 16,
											weight: "bold"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1100,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1094,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1068,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "text-sm font-medium text-slate-900 bg-slate-100 px-3 py-1.5 rounded-lg flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-4 h-4 text-slate-500" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1106,
										columnNumber: 21
									}, this), formatInUserTimezone(selectedTripDate, activeTimezone, "MMMM d, yyyy")]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1105,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV(Button, {
									variant: "ghost",
									size: "sm",
									onClick: () => setSelectedTripDate(null),
									className: "h-8 px-3 text-xs hover:bg-slate-100 text-slate-500",
									children: "Show all"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1113,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1104,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV(Funnel, {
										size: 16,
										className: "text-slate-400"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1126,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("select", {
										value: tripStatusFilter,
										onChange: (e) => setTripStatusFilter(e.target.value),
										className: "h-8 rounded-lg border border-slate-200 bg-white px-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#3D5A3D]/20",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "all",
												children: "All Status"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1134,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "pending",
												children: "Pending"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1135,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "assigned",
												children: "Assigned"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1136,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "in_progress",
												children: "In Progress"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1137,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "completed",
												children: "Completed"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1138,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "cancelled",
												children: "Cancelled"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1139,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1127,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-slate-500",
										children: [
											filteredTrips.length,
											" trip",
											filteredTrips.length !== 1 ? "s" : ""
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1141,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1125,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1065,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1064,
						columnNumber: 11
					}, this),
					isLoadingTrips ? /* @__PURE__ */ _jsxDEV("div", {
						className: "flex h-48 items-center justify-center",
						children: /* @__PURE__ */ _jsxDEV(Loader2, { className: "h-8 w-8 animate-spin text-slate-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1152,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1151,
						columnNumber: 13
					}, this) : paginatedTrips.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col items-center justify-center p-12 bg-white rounded-2xl border border-dashed border-slate-300 gap-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-center w-12 h-12 rounded-full bg-slate-50 border border-slate-100",
							children: /* @__PURE__ */ _jsxDEV(Calendar, { className: "w-6 h-6 text-slate-300" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1157,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1156,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "text-center",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-base font-semibold text-slate-900",
								children: "No trips found"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1160,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-sm text-slate-500",
								children: [
									"No trips scheduled for",
									" ",
									selectedTripDate ? formatInUserTimezone(selectedTripDate, activeTimezone, "MMMM d, yyyy") : formatInUserTimezone(tripMonth, activeTimezone, "MMMM yyyy"),
									tripStatusFilter !== "all" ? ` with status "${tripStatusFilter.replace("_", " ")}"` : ""
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1163,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1159,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1155,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
						children: paginatedTrips.map((trip) => /* @__PURE__ */ _jsxDEV("div", {
							onClick: () => onTripClick?.(trip.id),
							className: "group bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all cursor-pointer overflow-hidden flex flex-col",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "p-4 border-b border-slate-50 flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: cn("px-2.5 py-0.5 rounded-full text-xs font-semibold border", statusColors[trip.status]),
									children: trip.status.replace("_", " ").toUpperCase()
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1192,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-medium text-slate-400",
									children: trip.trip_type
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1200,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1191,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "p-5 space-y-4 flex-1",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2 text-slate-600",
										children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1207,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-sm font-medium",
											children: [
												formatInUserTimezone(trip.pickup_time, activeTimezone, "MMM d, yyyy"),
												" ",
												"at",
												" ",
												formatInUserTimezone(trip.pickup_time, activeTimezone, "h:mm a")
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1208,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1206,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-start gap-2 text-slate-600",
											children: [/* @__PURE__ */ _jsxDEV(MapPin, { className: "w-4 h-4 mt-0.5 flex-shrink-0 text-red-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1226,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-sm line-clamp-1",
												children: trip.pickup_location
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1227,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1225,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-start gap-2 text-slate-600",
											children: [/* @__PURE__ */ _jsxDEV(MapPin, { className: "w-4 h-4 mt-0.5 flex-shrink-0 text-emerald-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1232,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-sm line-clamp-1",
												children: trip.dropoff_location
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1233,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1231,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1224,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "pt-3 border-t border-slate-50 text-xs text-slate-500",
										children: ["Driver: ", trip.driver?.full_name || "Unassigned"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1240,
										columnNumber: 21
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1205,
								columnNumber: 19
							}, this)]
						}, trip.id, true, {
							fileName: _jsxFileName,
							lineNumber: 1185,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1183,
						columnNumber: 13
					}, this),
					totalTripPages > 1 && /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-center gap-2 pt-4",
						children: [
							/* @__PURE__ */ _jsxDEV(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => setTripPage((p) => Math.max(1, p - 1)),
								disabled: tripPage === 1,
								className: "h-8 w-8 p-0",
								children: /* @__PURE__ */ _jsxDEV(ChevronLeft, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1259,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1252,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-sm text-slate-600 px-2",
								children: [
									"Page ",
									tripPage,
									" of ",
									totalTripPages
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1261,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => setTripPage((p) => Math.min(totalTripPages, p + 1)),
								disabled: tripPage === totalTripPages,
								className: "h-8 w-8 p-0",
								children: /* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1273,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1264,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1251,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1062,
				columnNumber: 9
			}, this),
			activeTab === "credits" && /* @__PURE__ */ _jsxDEV(PatientCreditTab, {
				patientId: patient.id,
				patientName: patient.full_name,
				monthlyCredit: patient.monthly_credit,
				creditUsedFor: patient.credit_used_for,
				notes: patient.notes,
				referralDate: patient.referral_date,
				referralExpiration: patient.referral_expiration_date,
				serviceType: patient.service_type,
				onDayClick: (date) => {
					setSelectedTripDate(date);
					setActiveTab("trips");
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1281,
				columnNumber: 9
			}, this),
			activeTab === "summary" && /* @__PURE__ */ _jsxDEV(PatientSummaryTab, {
				patientId: patient.id,
				patientName: patient.full_name
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1298,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(PatientForm, {
				open: isEditing,
				onOpenChange: setIsEditing,
				initialData: {
					id: patient.id,
					full_name: patient.full_name,
					email: patient.email || "",
					phone: patient.phone || "",
					primary_address: patient.primary_address || "",
					dob: patient.dob || patient.date_of_birth || "",
					county: patient.county || "",
					waiver_type: patient.waiver_type || "",
					referral_by: patient.referral_by || "",
					referral_date: patient.referral_date || "",
					referral_expiration_date: patient.referral_expiration_date || "",
					service_type: patient.service_type || "",
					case_manager: patient.case_manager || "",
					case_manager_phone: patient.case_manager_phone || "",
					case_manager_email: patient.case_manager_email || "",
					monthly_credit: patient.monthly_credit?.toString() || "",
					credit_used_for: patient.credit_used_for || "",
					medicaid_id: patient.medicaid_id || "",
					vehicle_type_need: patient.vehicle_type_need || "",
					notes: patient.notes || "",
					sal_status: patient.sal_status || "",
					sal_effective_date: patient.sal_effective_date || "",
					sal_through_date: patient.sal_through_date || "",
					sal_pending_reason: patient.sal_pending_reason || ""
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1305,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(DeleteConfirmationDialog, {
				open: showDeleteDialog,
				onOpenChange: setShowDeleteDialog,
				onConfirm: handleDelete,
				title: "Delete Patient?",
				description: "This action cannot be undone. This will permanently delete the patient and all associated data",
				itemName: patient.full_name,
				isDeleting
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1336,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 375,
		columnNumber: 5
	}, this);
}
_s(PatientDetailsPage, "LNCKpI4tc0+pr0xI9AtmjgWVGUE=", false, function() {
	return [
		useQueryState,
		useAuth,
		useOrganization,
		usePermissions,
		useOnboarding,
		useQueryClient,
		useCanManageUserAccess,
		useQueryState,
		useQuery,
		useQuery,
		useQuery,
		useQuery
	];
});
_c = PatientDetailsPage;
var _c;
$RefreshReg$(_c, "PatientDetailsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/patient-details-page.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/yahiaalhejoj/meditrans/src/components/patient-details-page.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/yahiaalhejoj/meditrans/src/components/patient-details-page.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/yahiaalhejoj/meditrans/src/components/patient-details-page.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGVBQWU7QUFDbEMsU0FBUyxzQkFBc0IscUJBQXFCO0FBQ3BELFNBQ0UsV0FDQSxVQUNBLE9BQ0EsTUFDQSxRQUNBLFNBQ0EsUUFDQSxhQUNBLFVBQ0EsV0FDQSxZQUNBLE9BQ0EsYUFDQSxjQUNBLGdCQUNBLE9BQ0EsU0FDQSxjQUNBLFNBQ0EsYUFDQSxlQUNLO0FBQ1AsU0FDRSxXQUNBLFlBQ0EsZUFDQSxRQUNBLE9BQ0EsU0FDQSxvQkFDQSxPQUNBLGtCQUNLO0FBQ1AsU0FBUyxVQUFVLHNCQUFzQjtBQUN6QyxTQUFTLGdCQUFnQjtBQUN6QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxJQUFJLHlCQUF5QjtBQUN0QyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLGdDQUFnQztBQUN6QyxTQUFTLHFCQUFxQjtBQUM5QixTQUFTLHdCQUF3QjtBQUVqQyxTQUFTLGVBQWU7QUFDeEIsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyx5QkFBeUI7QUFDbEMsU0FDRSxtQkFDQSxzQkFDQSxzQkFDSztBQUNQLFNBQVMsMEJBQTBCO0FBQ25DLFNBQVMsOEJBQThCO0FBQ3ZDLFNBQ0UsbUJBQ0EsOEJBQ0s7Ozs7QUFxRFAsTUFBTSxlQUEyQztDQUMvQyxTQUFTO0NBQ1QsVUFBVTtDQUNWLFVBQVU7Q0FDVixVQUFVO0NBQ1YsU0FBUztDQUNULGFBQWE7Q0FDYixXQUFXO0NBQ1gsV0FBVztDQUNYLFNBQVM7Q0FDVCxTQUFTO0NBQ1QsUUFBUTtDQUNSLGtCQUFrQjtDQUNsQixtQkFBbUI7QUFDckI7QUFFQSxTQUFTLFdBQVcsU0FBd0IsV0FBbUIsT0FBTztDQUNwRSxJQUFJLENBQUMsU0FBUyxPQUFPOztDQUdyQixJQUNFLFFBQVEsV0FBVyxNQUNuQixRQUFRLFNBQVMsR0FBRyxLQUNwQixDQUFDLFFBQVEsU0FBUyxHQUFHLEdBQ3JCO0VBQ0EsT0FBTyxxQkFBcUIsU0FBUyxPQUFPLGNBQWM7Q0FDNUQ7Q0FFQSxPQUFPLHFCQUFxQixTQUFTLFVBQVUsY0FBYztBQUMvRDtBQUVBLE1BQU0saUJBQWlCO0FBRXZCLE9BQU8sU0FBUyxtQkFBbUIsRUFDakMsSUFDQSxRQUNBLGVBQzBCOztDQUMxQixNQUFNLENBQUMsV0FBVyxnQkFBZ0IsY0FFaEMsV0FBVztFQUNYLGNBQWM7RUFDZCxRQUFRLFVBQ0wsU0FDRDtDQUNKLENBQUM7Q0FDRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxLQUFLO0NBQ2hELE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsS0FBSztDQUM5RCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxLQUFLO0NBQ2xELE1BQU0sRUFBRSxZQUFZLFFBQVE7Q0FDNUIsTUFBTSxFQUFFLHdCQUF3QixnQkFBZ0I7Q0FDaEQsTUFBTSxFQUFFLGlCQUFpQixzQkFBc0IsZUFBZTtDQUM5RCxNQUFNLEVBQUUsZUFBZSxjQUFjO0NBQ3JDLE1BQU0sY0FBYyxlQUFlO0NBQ25DLE1BQU0sc0JBQXNCLHVCQUF1QjtDQUVuRCxNQUFNLGlCQUFpQixjQUNmLGtCQUFrQixTQUFTLG1CQUFtQixHQUNwRCxDQUFDLFNBQVMsbUJBQW1CLENBQy9COztDQUdBLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixlQUFlO0VBQy9DLE1BQU0sTUFBTSxJQUFJLEtBQUs7RUFDckIsT0FBTyxJQUFJLEtBQUssSUFBSSxZQUFZLEdBQUcsSUFBSSxTQUFTLEdBQUcsQ0FBQztDQUN0RCxDQUFDO0NBQ0QsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLENBQUM7Q0FDMUMsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FDOUMsS0FDRjtDQUNBLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLGNBQWMsUUFBUTtFQUNwRSxRQUFRLE1BQU8sSUFBSSxJQUFJLEtBQUssQ0FBQyxJQUFJO0VBQ2pDLFlBQVksTUFBTSxHQUFHLFlBQVksS0FBSztDQUN4QyxDQUFDO0NBRUQsTUFBTSxvQkFBb0IsbUJBQW1COztDQUc3QyxNQUFNLEVBQUUsTUFBTSxTQUFTLFdBQVcscUJBQXFCLFNBQVM7RUFDOUQsVUFBVSxDQUFDLFdBQVcsRUFBRTtFQUN4QixTQUFTLFlBQVk7R0FDbkIsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFNLFNBQzNCLEtBQUssVUFBVSxDQUFDLENBQ2hCLE9BQU8sR0FBRyxDQUFDLENBQ1gsR0FBRyxNQUFNLEVBQUUsQ0FBQyxDQUNaLE9BQU87R0FFVixJQUFJLE9BQU8sTUFBTTtHQUNqQixPQUFPO0VBQ1Q7RUFDQSxTQUFTLENBQUMsQ0FBQztDQUNiLENBQUM7O0NBR0QsTUFBTSxFQUFFLE1BQU0sYUFBYSxDQUFDLE1BQU0sU0FBUztFQUN6QyxVQUFVLENBQUMsZUFBZSxFQUFFO0VBQzVCLFNBQVMsWUFBWTtHQUNuQixNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sU0FDM0IsS0FBSyxxQkFBcUIsQ0FBQyxDQUMzQixPQUFPLEdBQUcsQ0FBQyxDQUNYLEdBQUcsY0FBYyxFQUFFLENBQUMsQ0FDcEIsTUFBTSxjQUFjLEVBQUUsV0FBVyxNQUFNLENBQUM7R0FDM0MsSUFBSSxPQUFPLE1BQU07R0FDakIsT0FBTztFQUNUO0VBQ0EsU0FBUyxDQUFDLENBQUM7Q0FDYixDQUFDOztDQUdELE1BQU0sRUFBRSxNQUFNLFdBQVcsQ0FBQyxHQUFHLFdBQVcsbUJBQW1CLFNBQVM7RUFDbEUsVUFBVSxDQUFDLGlCQUFpQixFQUFFO0VBQzlCLFNBQVMsWUFBWTtHQUNuQixNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sU0FDM0IsS0FBSyxPQUFPLENBQUMsQ0FDYixPQUNDOzs7U0FJRixDQUFDLENBQ0EsR0FBRyxjQUFjLEVBQUUsQ0FBQyxDQUNwQixNQUFNLGVBQWUsRUFBRSxXQUFXLE1BQU0sQ0FBQztHQUU1QyxJQUFJLE9BQU8sTUFBTTtHQUNqQixPQUFPO0VBQ1Q7RUFDQSxTQUFTLENBQUMsQ0FBQztDQUNiLENBQUM7O0NBR0QsTUFBTSxFQUFFLE1BQU0sV0FBVyxNQUFNLFNBQVM7RUFDdEMsVUFBVSxDQUFDLHNCQUFzQixFQUFFO0VBQ25DLFNBQVMsWUFBWTtHQUNuQixNQUFNLEVBQUUsT0FBTyxVQUFVLE1BQU0sU0FDNUIsS0FBSyxhQUFhLENBQUMsQ0FDbkIsT0FBTyxLQUFLO0lBQUUsT0FBTztJQUFTLE1BQU07R0FBSyxDQUFDLENBQUMsQ0FDM0MsR0FBRyxXQUFXLGtCQUFrQixDQUFDLENBQ2pDLEdBQUcsU0FBUyxFQUFFO0dBQ2pCLElBQUksT0FBTyxNQUFNO0dBQ2pCLE9BQU8sU0FBUztFQUNsQjtDQUNGLENBQUM7O0NBR0QsTUFBTSxnQkFBZ0IsY0FBYzs7RUFFbEMsSUFBSSxrQkFBa0I7R0FDcEIsTUFBTSxnQkFBZ0IscUJBQ3BCLGtCQUNBLGdCQUNBLFlBQ0Y7R0FDQSxPQUFPLFNBQVMsUUFBUSxTQUFTO0lBQy9CLE1BQU0sY0FBYyxxQkFDbEIsS0FBSyxhQUNMLGdCQUNBLFlBQ0Y7SUFDQSxNQUFNLGdCQUNKLHFCQUFxQixTQUFTLEtBQUssV0FBVztJQUNoRCxPQUFPLGdCQUFnQixpQkFBaUI7R0FDMUMsQ0FBQztFQUNIOztFQUdBLE1BQU0sV0FBVyxxQkFBcUIsV0FBVyxnQkFBZ0IsU0FBUztFQUMxRSxNQUFNLGtCQUFrQixlQUN0QixHQUFHLFNBQVMsTUFDWixTQUNBLGNBQ0Y7O0VBR0EsTUFBTSxPQUFPLFNBQVMsU0FBUyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDNUMsTUFBTSxRQUFRLFNBQVMsU0FBUyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTSxVQUFVLElBQUksS0FBSyxNQUFNLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUTtFQUNqRCxNQUFNLGdCQUFnQixlQUNwQixHQUFHLFNBQVMsR0FBRyxXQUNmLFlBQ0EsY0FDRjtFQUVBLE9BQU8sU0FBUyxRQUFRLFNBQVM7R0FDL0IsTUFBTSxXQUFXLElBQUksS0FBSyxLQUFLLFdBQVc7R0FDMUMsTUFBTSxVQUFVLFlBQVksbUJBQW1CLFlBQVk7R0FDM0QsTUFBTSxnQkFDSixxQkFBcUIsU0FBUyxLQUFLLFdBQVc7R0FDaEQsT0FBTyxXQUFXO0VBQ3BCLENBQUM7Q0FDSCxHQUFHO0VBQUM7RUFBVTtFQUFXO0VBQWtCO0VBQWtCO0NBQWMsQ0FBQzs7Q0FHNUUsTUFBTSxpQkFBaUIsY0FBYztFQUNuQyxNQUFNLFNBQVMsV0FBVyxLQUFLO0VBQy9CLE9BQU8sY0FBYyxNQUFNLE9BQU8sUUFBUSxjQUFjO0NBQzFELEdBQUcsQ0FBQyxlQUFlLFFBQVEsQ0FBQztDQUU1QixNQUFNLGlCQUFpQixLQUFLLEtBQUssY0FBYyxTQUFTLGNBQWM7O0NBR3RFLGNBQWM7RUFDWixZQUFZLENBQUM7Q0FDZixHQUFHO0VBQUM7RUFBVztFQUFrQjtDQUFnQixDQUFDO0NBRWxELE1BQU0sc0JBQXNCO0VBQzFCLGNBQ0csU0FBUyxJQUFJLEtBQUssS0FBSyxZQUFZLEdBQUcsS0FBSyxTQUFTLElBQUksR0FBRyxDQUFDLENBQy9EO0NBQ0Y7Q0FFQSxNQUFNLHNCQUFzQjtFQUMxQixjQUNHLFNBQVMsSUFBSSxLQUFLLEtBQUssWUFBWSxHQUFHLEtBQUssU0FBUyxJQUFJLEdBQUcsQ0FBQyxDQUMvRDtDQUNGO0NBRUEsTUFBTSx5QkFBeUI7RUFDN0IsTUFBTSxNQUFNLElBQUksS0FBSztFQUNyQixhQUFhLElBQUksS0FBSyxJQUFJLFlBQVksR0FBRyxJQUFJLFNBQVMsR0FBRyxDQUFDLENBQUM7Q0FDN0Q7Q0FFQSxNQUFNLGVBQWUsWUFBWTtFQUMvQixJQUFJLFlBQVk7RUFDaEIsY0FBYyxJQUFJO0VBQ2xCLElBQUk7R0FDRixNQUFNLEVBQUUsVUFBVSxNQUFNLFNBQVMsS0FBSyxVQUFVLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLE1BQU0sRUFBRTtHQUN0RSxJQUFJLE9BQU8sTUFBTTtHQUNqQixZQUFZLGtCQUFrQixFQUFFLFVBQVUsQ0FBQyxVQUFVLEVBQUUsQ0FBQztHQUN4RCxZQUFZLGtCQUFrQixFQUM1QixVQUFVO0lBQUM7SUFBUztJQUFvQixxQkFBcUI7R0FBRSxFQUNqRSxDQUFDO0dBQ0QsT0FBTztFQUNULFNBQVMsS0FBSztHQUNaLFFBQVEsTUFBTSw2QkFBNkIsR0FBRztFQUNoRCxVQUFVO0dBQ1IsY0FBYyxLQUFLO0VBQ3JCO0NBQ0Y7Q0FFQSxJQUFJLGtCQUFrQjtFQUNwQixPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsU0FBRCxFQUFTLFdBQVUsc0NBQXVDOzs7OztFQUN2RDs7Ozs7Q0FFVDtDQUVBLElBQUksQ0FBQyxTQUFTO0VBQ1osT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBaUI7R0FBb0I7Ozs7YUFDbEQsd0JBQUMsUUFBRDtJQUFRLFNBQVE7SUFBTyxTQUFTO2NBQVE7R0FFaEM7Ozs7V0FDTDs7Ozs7O0NBRVQ7Q0FFQSxNQUFNLGlCQUFpQixRQUFRLGFBQWE7Q0FFNUMsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7Z0JBRVYsd0JBQUMsV0FBRDtPQUFXLE1BQU07T0FBSSxXQUFVO01BQWtCOzs7OztLQUMzQzs7OztlQUNSLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQ1gsUUFBUTtNQUNQOzs7O2dCQUNKLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQW9HO1FBRTlHOzs7OztRQUNOLHdCQUFDLG1CQUFELEVBQW1CLFVBQVUsZUFBaUI7Ozs7O1FBQzlDLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUF5QyxRQUNsQyxRQUFRLEdBQUcsVUFBVSxHQUFHLENBQUMsQ0FDMUI7Ozs7OztPQUNIOzs7OztjQUNGOzs7OzthQUNGOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQ0UsU0FBUTtNQUNSLGVBQ0UsbUJBQ0UsV0FDQSxTQUNBLHFCQUFxQixRQUFRLElBQzdCLGNBQ0Y7TUFFRixXQUFVO2dCQVZaLENBWUUsd0JBQUMsU0FBRCxFQUFTLE1BQU0sR0FBSzs7OztnQkFBQyxXQUVmOzs7OztnQkFDTixxQkFBcUIsd0JBQ3JCO01BQ0csbUJBQ0Msd0JBQUMsUUFBRDtPQUNFLFNBQVE7T0FDUixlQUFlLGFBQWEsSUFBSTtPQUNoQyxXQUFVO2lCQUhaLENBS0Usd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7OztpQkFBQyxjQUVkOzs7Ozs7TUFFVix3QkFBQyx3QkFBRDtPQUNFLFlBQVc7T0FDWCxVQUFVLFFBQVE7T0FDbEIsYUFBYSxRQUFRO09BQ3JCLFVBQVU7T0FDVixXQUFXO09BQ0M7T0FDWixpQkFBaUI7UUFDZixZQUFZLGtCQUFrQixFQUFFLFVBQVUsQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDO1FBQzNELFlBQVksa0JBQWtCLEVBQzVCLFVBQVUsQ0FBQyxZQUFZLHFCQUFxQixFQUFFLEVBQ2hELENBQUM7T0FDSDtNQUNEOzs7OztNQUNBLHFCQUNDLHdCQUFDLFFBQUQ7T0FDRSxTQUFRO09BQ1IsZUFBZSxvQkFBb0IsSUFBSTtPQUN2QyxVQUFVO09BQ1YsV0FBVTtpQkFKWixDQU1FLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7aUJBQUMsZ0JBRWI7Ozs7OztLQUVWOzs7O2FBRUQ7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGFBQWEsVUFBVTtPQUN0QyxXQUFXLEdBQ1QsMklBQ0EsY0FBYyxhQUNWLHlFQUNBLGdJQUNOO2lCQVBGLENBU0Usd0JBQUMsb0JBQUQ7UUFDRSxNQUFNO1FBQ04sUUFBTztRQUNQLFdBQVU7T0FDWDs7OztpQkFBQyxVQUVJOzs7Ozs7TUFDUix3QkFBQyxVQUFEO09BQ0UsZUFBZSxhQUFhLFdBQVc7T0FDdkMsV0FBVyxHQUNULDJJQUNBLGNBQWMsY0FDVix5RUFDQSxnSUFDTjtpQkFQRjtRQVNFLHdCQUFDLE9BQUQ7U0FBTyxNQUFNO1NBQUksUUFBTztTQUFVLFdBQVU7UUFBa0I7Ozs7O1FBQUM7UUFFL0Qsd0JBQUMsUUFBRDtTQUNFLFdBQVcsR0FDVCxrREFDQSxjQUFjLGNBQ1YsNEJBQ0EsNkJBQ047bUJBRUM7UUFDRzs7Ozs7T0FDQTs7Ozs7O01BQ1Isd0JBQUMsVUFBRDtPQUNFLGVBQWUsYUFBYSxPQUFPO09BQ25DLFdBQVcsR0FDVCwySUFDQSxjQUFjLFVBQ1YseUVBQ0EsZ0lBQ047aUJBUEY7UUFTRSx3QkFBQyxZQUFEO1NBQVksTUFBTTtTQUFJLFFBQU87U0FBVSxXQUFVO1FBQWtCOzs7OztRQUFDO1FBRXBFLHdCQUFDLFFBQUQ7U0FDRSxXQUFXLEdBQ1Qsa0RBQ0EsY0FBYyxVQUNWLDRCQUNBLDZCQUNOO21CQUVDLFNBQVM7UUFDTjs7Ozs7T0FDQTs7Ozs7O09BRU4scUJBQXFCLFFBQVEsbUJBQzdCLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGFBQWEsU0FBUztPQUNyQyxXQUFXLEdBQ1QsMklBQ0EsY0FBYyxZQUNWLHlFQUNBLGdJQUNOO2lCQVBGO1FBU0Usd0JBQUMsT0FBRDtTQUFPLFFBQU87U0FBVSxNQUFNO1NBQUksV0FBVTtRQUFrQjs7Ozs7UUFBQztRQUU5RCxRQUFRLGtCQUNQLHdCQUFDLFFBQUQ7U0FDRSxXQUFXLEdBQ1Qsa0RBQ0EsY0FBYyxZQUNWLDRCQUNBLGlDQUNOO21CQU5GLENBT0MsS0FDRyxRQUFRLGVBQWUsZUFBZSxDQUNwQzs7Ozs7O09BRUY7Ozs7OztNQUVWLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGFBQWEsU0FBUztPQUNyQyxXQUFXLEdBQ1QsMklBQ0EsY0FBYyxZQUNWLHlFQUNBLGdJQUNOO2lCQVBGLENBU0Usd0JBQUMsU0FBRDtRQUFTLE1BQU07UUFBSSxRQUFPO1FBQVUsV0FBVTtPQUFrQjs7OztpQkFBQyxlQUUzRDs7Ozs7O0tBQ0w7Ozs7OztHQUNGOzs7OztHQUdKLGNBQWMsY0FDYix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBRUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUVFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQTRDO09BRXREOzs7O2lCQUNKLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNiLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlCQUEwQjs7Ozs7V0FDM0M7Ozs7cUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUE4RDtXQUV4RTs7OztxQkFDSCx3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFDVixXQUFXLFFBQVEsZUFBZSxjQUFjO1dBQ2hEOzs7O21CQUNBOzs7O21CQUNGOzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNiLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHlCQUEwQjs7Ozs7V0FDeEM7Ozs7cUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUE4RDtXQUV4RTs7OztxQkFDSCx3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFDVixRQUFRLFFBQ0wsa0JBQWtCLFFBQVEsS0FBSyxJQUMvQjtXQUNIOzs7O21CQUNBOzs7O21CQUNGOzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNiLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHlCQUEwQjs7Ozs7V0FDekM7Ozs7cUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUE4RDtXQUV4RTs7OztxQkFDSCx3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFDVixRQUFRLG1CQUFtQjtXQUMzQjs7OzttQkFDQTs7OzttQkFDRjs7Ozs7O1NBQ0Y7Ozs7O2tCQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDYix3QkFBQyxNQUFELEVBQU0sV0FBVSx5QkFBMEI7Ozs7O1VBQ3ZDOzs7O29CQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBOEQ7VUFFeEU7Ozs7b0JBQ0gsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQ1YsUUFBUSxTQUFTO1VBQ2pCOzs7O2tCQUNBOzs7O2tCQUNGOzs7OzttQkFDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNiLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHlCQUEwQjs7Ozs7VUFDekM7Ozs7b0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUE4RDtVQUV4RTs7OztvQkFDSCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFDVixRQUFRLFVBQVU7VUFDbEI7Ozs7a0JBQ0E7Ozs7a0JBQ0Y7Ozs7O2lCQUNGOzs7OztnQkFDRjs7Ozs7ZUFDRjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBNEM7T0FFdEQ7Ozs7aUJBQ0osd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBOEQ7VUFFeEU7Ozs7b0JBQ0gsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQ1YsUUFBUSxnQkFBZ0I7VUFDeEI7Ozs7a0JBQ0E7Ozs7O1VBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUE4RDtVQUV4RTs7OztvQkFDSCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFDVixRQUFRLGVBQWU7VUFDdkI7Ozs7a0JBQ0E7Ozs7O1VBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUE4RDtVQUV4RTs7OztvQkFDSCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFDVixRQUFRLHFCQUFxQjtVQUM3Qjs7OztrQkFDQTs7Ozs7U0FDRjs7Ozs7a0JBQ0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQThEO1NBRXhFOzs7O21CQUNILHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUNWLFFBQVEsZUFBZTtTQUN2Qjs7OztpQkFDQTs7OzttQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQThEO1NBRXhFOzs7O21CQUNILHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFiO1dBQ0csUUFBUSxnQkFDTCxXQUFXLFFBQVEsZUFBZSxjQUFjLElBQ2hEO1dBQ0osd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXNCO1dBQU87Ozs7O1dBQzVDLFFBQVEsMkJBQ0wsV0FDRSxRQUFRLDBCQUNSLGNBQ0YsSUFDQTtVQUNIOzs7OztpQkFDQTs7OztpQkFDRjs7Ozs7Z0JBQ0Y7Ozs7O2VBQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZCxDQUNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLHlCQUEwQjs7OzttQkFBQyxpQkFFOUM7Ozs7O2tCQUNKLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUF5QjtVQUFlOzs7O29CQUNyRCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFDVixRQUFRLGdCQUFnQjtVQUN4Qjs7OztrQkFDQTs7Ozs7VUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQXlCO1VBQWlCOzs7O29CQUN2RCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFDVixRQUFRLHFCQUNMLGtCQUFrQixRQUFRLGtCQUFrQixJQUM1QztVQUNIOzs7O2tCQUNBOzs7OztVQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBeUI7VUFBUTs7OztvQkFDOUMsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQ1YsUUFBUSxzQkFBc0I7VUFDOUI7Ozs7a0JBQ0E7Ozs7O1NBQ0Y7Ozs7O2dCQUNGOzs7OztpQkFDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFkLENBQ0Usd0JBQUMsWUFBRCxFQUFZLFdBQVUseUJBQTBCOzs7O21CQUFDLGlCQUUvQzs7Ozs7a0JBQ0osd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQXlCO1VBQWlCOzs7O29CQUN2RCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFDVixRQUFRLGlCQUNMLElBQUksUUFBUSxlQUFlLFFBQVEsQ0FBQyxNQUNwQztVQUNIOzs7O2tCQUNBOzs7OztVQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBeUI7VUFBa0I7Ozs7b0JBQ3hELHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUNWLFFBQVEsbUJBQW1CO1VBQzNCOzs7O2tCQUNBOzs7OztVQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBeUI7VUFBYzs7OztvQkFDcEQsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQ1YsUUFBUSxlQUFlO1VBQ3ZCOzs7O2tCQUNBOzs7OztTQUNGOzs7OztnQkFDRjs7Ozs7ZUFDRjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF1QztRQUVqRDs7OztrQkFDSix3QkFBQyxVQUFELEVBQVUsV0FBVSx5QkFBMEI7Ozs7Z0JBQzNDOzs7OztpQkFDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWixRQUFRLFFBQ1Asd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQ1YsUUFBUTtRQUNSOzs7O21CQUVILHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUF3QjtRQUVsQzs7Ozs7T0FFRjs7OztlQUNGOzs7Ozs7S0FDRjs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBcUU7T0FFL0U7Ozs7aUJBQ0osd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUF5QjtVQUFpQjs7OztvQkFDMUQsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQ2IsU0FBUztVQUNOOzs7O2tCQUNIOzs7Ozs7U0FDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUF5QjtVQUFvQjs7OztvQkFDN0Qsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQ2IsU0FBUyxTQUFTLElBQ2YsV0FBVyxTQUFTLEVBQUUsQ0FBQyxhQUFhLGNBQWMsSUFDbEQ7VUFDQTs7OztrQkFDSDs7Ozs7O1NBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBeUI7VUFBYzs7OztvQkFDdkQsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQ2IsV0FBVyxRQUFRLFlBQVksY0FBYztVQUMxQzs7OztrQkFDSDs7Ozs7O1FBQ0Y7Ozs7O2VBQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FDRSxXQUFXLEdBQ1Qsb0NBQ0EsUUFBUSxlQUFlLGNBQ3JCLHVDQUNGLFFBQVEsZUFBZSxhQUNyQixtQ0FDRixRQUFRLGVBQWUsYUFDckIsK0JBQ0YsQ0FBQyxRQUFRLGNBQWMsMkJBQ3pCO2lCQVZGLENBWUUsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQsQ0FDRSx3QkFBQyxnQkFBRCxFQUFnQixXQUFVLHlCQUEwQjs7OztrQkFBQyxZQUVuRDs7Ozs7aUJBR0osd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNHLFFBQVEsZUFBZSxjQUN0QixnREFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDYix3QkFBQyxjQUFELEVBQWMsV0FBVSwyQkFBNEI7Ozs7O1VBQ2pEOzs7O29CQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBeUM7VUFFbkQ7Ozs7b0JBQ0YsUUFBUSxzQkFDUCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBYjtZQUNHLFdBQ0MsUUFBUSxvQkFDUixjQUNGO1lBQ0Esd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQU87WUFBTzs7Ozs7WUFDN0IsUUFBUSxtQkFDTCxXQUNFLFFBQVEsa0JBQ1IsY0FDRixJQUNBO1dBQ0g7Ozs7O2tCQUVGOzs7O2tCQUNMOzs7OztVQUVILFFBQVEsZUFBZSxhQUN0QixnREFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDYix3QkFBQyxPQUFELEVBQU8sV0FBVSx5QkFBMEI7Ozs7O1VBQ3hDOzs7O29CQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBdUM7VUFFakQ7Ozs7b0JBQ0YsUUFBUSxzQkFDUCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFDVixRQUFRO1VBQ1I7Ozs7a0JBRUY7Ozs7a0JBQ0w7Ozs7O1VBRUgsUUFBUSxlQUFlLGFBQ3RCLGdEQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNiLHdCQUFDLFNBQUQsRUFBUyxXQUFVLHVCQUF3Qjs7Ozs7VUFDeEM7Ozs7b0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFxQztVQUUvQzs7OztvQkFDSCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBeUI7VUFFbkM7Ozs7a0JBQ0E7Ozs7a0JBQ0w7Ozs7O1VBRUgsUUFBUSxlQUFlLFNBQ3RCLGdEQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNiLHdCQUFDLGFBQUQsRUFBYSxXQUFVLHlCQUEwQjs7Ozs7VUFDOUM7Ozs7b0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUF1QztVQUVqRDs7OztvQkFDSCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBeUI7VUFFbkM7Ozs7a0JBQ0E7Ozs7a0JBQ0w7Ozs7O1VBRUgsQ0FBQyxRQUFRLGNBQ1IsZ0RBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ2Isd0JBQUMsZ0JBQUQsRUFBZ0IsV0FBVSx5QkFBMEI7Ozs7O1VBQ2pEOzs7O29CQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBcUM7VUFFL0M7Ozs7b0JBQ0gsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQXlCO1VBRW5DOzs7O2tCQUNBOzs7O2tCQUNMOzs7OztTQUVEOzs7OztrQkFHSixXQUFXLFNBQVMsS0FDbkIsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBYjtXQUNFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLGNBQWU7Ozs7O1dBQUM7V0FDekIsV0FBVztXQUFPO1VBQzNCOzs7OzttQkFDSCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWixXQUFXLEtBQUssVUFDZix3QkFBQyxPQUFEO1dBRUUsV0FBVyxHQUNULE1BQU0sV0FBVyxjQUFjLG9CQUMvQixNQUFNLFdBQVcsYUFBYSxrQkFDOUIsTUFBTSxXQUFXLGFBQWEsZ0JBQzlCLE1BQU0sV0FBVyxTQUFTLGFBQzVCO3FCQVBGLENBU0Usd0JBQUMsT0FBRDtZQUNFLFdBQVcsR0FDVCx5RUFDQSxNQUFNLFdBQVcsY0FBYyxrQkFDL0IsTUFBTSxXQUFXLGFBQWEsZ0JBQzlCLE1BQU0sV0FBVyxhQUFhLGNBQzlCLE1BQU0sV0FBVyxTQUFTLGNBQzVCO3NCQVBGO2FBU0csTUFBTSxXQUFXLGNBQ2hCLHdCQUFDLGNBQUQsRUFBYyxXQUFVLDJCQUE0Qjs7Ozs7YUFFckQsTUFBTSxXQUFXLGFBQ2hCLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHlCQUEwQjs7Ozs7YUFFNUMsTUFBTSxXQUFXLGFBQ2hCLHdCQUFDLFNBQUQsRUFBUyxXQUFVLHVCQUF3Qjs7Ozs7YUFFNUMsTUFBTSxXQUFXLFNBQ2hCLHdCQUFDLGFBQUQsRUFBYSxXQUFVLHlCQUEwQjs7Ozs7WUFFaEQ7Ozs7O3FCQUNMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmO2FBQ0Usd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQWYsQ0FDRSx3QkFBQyxRQUFEO2VBQ0UsV0FBVyxHQUNULDRCQUNBLE1BQU0sV0FBVyxjQUNmLG9CQUNGLE1BQU0sV0FBVyxhQUNmLGtCQUNGLE1BQU0sV0FBVyxhQUFhLGdCQUM5QixNQUFNLFdBQVcsU0FBUyxnQkFDNUI7eUJBRUMsTUFBTSxXQUFXLFFBQVEsUUFBUSxNQUFNO2NBQ3BDOzs7O3dCQUNOLHdCQUFDLFFBQUQ7ZUFBTSxXQUFVO3lCQUNiLElBQUksS0FBSyxNQUFNLFVBQVUsQ0FBQyxDQUFDLG1CQUMxQixTQUNBO2dCQUNFLE9BQU87Z0JBQ1AsS0FBSztnQkFDTCxNQUFNO2VBQ1IsQ0FDRjtjQUNJOzs7O3NCQUNIOzs7Ozs7YUFDSixNQUFNLFdBQVcsY0FDaEIsTUFBTSxrQkFDSix3QkFBQyxLQUFEO2NBQUcsV0FBVTt3QkFBYjtlQUNHLElBQUksS0FDSCxNQUFNLGlCQUFpQixXQUN6QixDQUFDLENBQUMsbUJBQW1CLFNBQVM7Z0JBQzVCLE9BQU87Z0JBQ1AsS0FBSztlQUNQLENBQUM7ZUFDRCx3QkFBQyxRQUFEO2dCQUFNLFdBQVU7MEJBQU87ZUFBTzs7Ozs7ZUFDN0IsTUFBTSxlQUNILElBQUksS0FDRixNQUFNLGVBQWUsV0FDdkIsQ0FBQyxDQUFDLG1CQUFtQixTQUFTO2dCQUM1QixPQUFPO2dCQUNQLEtBQUs7ZUFDUCxDQUFDLElBQ0Q7Y0FDSDs7Ozs7O2FBRU4sTUFBTSxXQUFXLGFBQ2hCLE1BQU0sa0JBQ0osd0JBQUMsS0FBRDtjQUFHLFdBQVU7d0JBQ1YsTUFBTTthQUNOOzs7OztZQUVKOzs7OzttQkFDRjthQW5GRSxNQUFNOzs7O2lCQW1GUixDQUNOO1NBQ0U7Ozs7aUJBQ0Y7Ozs7O2dCQUVKOzs7OztlQUNGOzs7Ozs7TUFFSixDQUFDLHFCQUNBLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7O2tCQUN4Qix3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBZ0I7UUFBZTs7OztnQkFDNUM7Ozs7O2lCQUNMLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUF5QztPQUluRDs7OztlQUNBOzs7Ozs7S0FFSjs7Ozs7WUFDRjs7Ozs7O0dBR04sY0FBYyxlQUNiLHdCQUFDLGlCQUFEO0lBQ0UsU0FBUztJQUNULFNBQVE7SUFDUixRQUFPO0dBQ1I7Ozs7O0dBR0YsY0FBYyxXQUNiLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FFRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUVHLENBQUMsbUJBQ0Esd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFEO1VBQ0UsU0FBUTtVQUNSLE1BQUs7VUFDTCxTQUFTO1VBQ1QsV0FBVTtvQkFFVix3QkFBQyxXQUFEO1dBQVcsTUFBTTtXQUFJLFFBQU87VUFBUTs7Ozs7U0FDOUI7Ozs7O1NBQ1Isd0JBQUMsUUFBRDtVQUNFLFNBQVE7VUFDUixNQUFLO1VBQ0wsU0FBUztVQUNULFdBQVU7b0JBSlosQ0FNRSx3QkFBQyxlQUFEO1dBQ0UsTUFBTTtXQUNOLFFBQU87V0FDUCxXQUFVO1VBQ1g7Ozs7b0JBQ0EscUJBQ0MsV0FDQSxnQkFDQSxXQUNGLENBQ007Ozs7OztTQUNSLHdCQUFDLFFBQUQ7VUFDRSxTQUFRO1VBQ1IsTUFBSztVQUNMLFNBQVM7VUFDVCxXQUFVO29CQUVWLHdCQUFDLFlBQUQ7V0FBWSxNQUFNO1dBQUksUUFBTztVQUFROzs7OztTQUMvQjs7Ozs7UUFDTDs7Ozs7a0JBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlCQUEwQjs7OzttQkFDN0MscUJBQ0Msa0JBQ0EsZ0JBQ0EsY0FDRixDQUNHOzs7OztrQkFDTCx3QkFBQyxRQUFEO1NBQ0UsU0FBUTtTQUNSLE1BQUs7U0FDTCxlQUFlLG9CQUFvQixJQUFJO1NBQ3ZDLFdBQVU7bUJBQ1g7UUFFTzs7OztnQkFDTDs7Ozs7aUJBSVAsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFEO1VBQVEsTUFBTTtVQUFJLFdBQVU7U0FBa0I7Ozs7O1NBQzlDLHdCQUFDLFVBQUQ7VUFDRSxPQUFPO1VBQ1AsV0FBVyxNQUNULG9CQUFvQixFQUFFLE9BQU8sS0FBMkI7VUFFMUQsV0FBVTtvQkFMWjtXQU9FLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFNO1dBQWtCOzs7OztXQUN0Qyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBVTtXQUFlOzs7OztXQUN2Qyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBVztXQUFnQjs7Ozs7V0FDekMsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQWM7V0FBbUI7Ozs7O1dBQy9DLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFZO1dBQWlCOzs7OztXQUMzQyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBWTtXQUFpQjs7Ozs7VUFDckM7Ozs7OztTQUNSLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQjtXQUNHLGNBQWM7V0FBTztXQUNyQixjQUFjLFdBQVcsSUFBSSxNQUFNO1VBQ2hDOzs7Ozs7UUFDSDs7Ozs7ZUFDRjs7Ozs7O0tBQ0Y7Ozs7O0tBR0osaUJBQ0Msd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsU0FBRCxFQUFTLFdBQVUsc0NBQXVDOzs7OztLQUN2RDs7OztnQkFDSCxlQUFlLFdBQVcsSUFDNUIsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxVQUFELEVBQVUsV0FBVSx5QkFBMEI7Ozs7O01BQzNDOzs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQXlDO09BRW5EOzs7O2lCQUNKLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFiO1NBQXNDO1NBQ2I7U0FDdEIsbUJBQ0cscUJBQ0Usa0JBQ0EsZ0JBQ0EsY0FDRixJQUNBLHFCQUNFLFdBQ0EsZ0JBQ0EsV0FDRjtTQUNILHFCQUFxQixRQUNsQixpQkFBaUIsaUJBQWlCLFFBQVEsS0FBSyxHQUFHLEVBQUUsS0FDcEQ7UUFDSDs7Ozs7ZUFDQTs7Ozs7Y0FDRjs7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1osZUFBZSxLQUFLLFNBQ25CLHdCQUFDLE9BQUQ7T0FFRSxlQUFlLGNBQWMsS0FBSyxFQUFFO09BQ3BDLFdBQVU7aUJBSFosQ0FNRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FDRSxXQUFXLEdBQ1QsMkRBQ0EsYUFBYSxLQUFLLE9BQ3BCO21CQUVDLEtBQUssT0FBTyxRQUFRLEtBQUssR0FBRyxDQUFDLENBQUMsWUFBWTtRQUN2Qzs7OztrQkFDTix3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFDYixLQUFLO1FBQ0Y7Ozs7Z0JBQ0g7Ozs7O2lCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7O29CQUMvQix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEI7WUFDRyxxQkFDQyxLQUFLLGFBQ0wsZ0JBQ0EsYUFDRjtZQUFHO1lBQUk7WUFDSjtZQUNGLHFCQUNDLEtBQUssYUFDTCxnQkFDQSxRQUNGO1dBQ0k7Ozs7O2tCQUNIOzs7Ozs7U0FHTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsNENBQTZDOzs7O3FCQUMvRCx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFDYixLQUFLO1dBQ0Y7Ozs7bUJBQ0g7Ozs7O29CQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsZ0RBQWlEOzs7O3FCQUNuRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFDYixLQUFLO1dBQ0Y7Ozs7bUJBQ0g7Ozs7O2tCQUNGOzs7Ozs7U0FHTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUFzRSxZQUMzRCxLQUFLLFFBQVEsYUFBYSxZQUNoQzs7Ozs7O1FBQ0Y7Ozs7O2VBQ0Y7U0ExREUsS0FBSzs7OzthQTBEUCxDQUNOO0tBQ0U7Ozs7O0tBSU4saUJBQWlCLEtBQ2hCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRDtRQUNFLFNBQVE7UUFDUixNQUFLO1FBQ0wsZUFBZSxhQUFhLE1BQU0sS0FBSyxJQUFJLEdBQUcsSUFBSSxDQUFDLENBQUM7UUFDcEQsVUFBVSxhQUFhO1FBQ3ZCLFdBQVU7a0JBRVYsd0JBQUMsYUFBRCxFQUFhLFdBQVUsVUFBVzs7Ozs7T0FDNUI7Ozs7O09BQ1Isd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCO1NBQThDO1NBQ3RDO1NBQVM7U0FBSztRQUNoQjs7Ozs7O09BQ04sd0JBQUMsUUFBRDtRQUNFLFNBQVE7UUFDUixNQUFLO1FBQ0wsZUFDRSxhQUFhLE1BQU0sS0FBSyxJQUFJLGdCQUFnQixJQUFJLENBQUMsQ0FBQztRQUVwRCxVQUFVLGFBQWE7UUFDdkIsV0FBVTtrQkFFVix3QkFBQyxjQUFELEVBQWMsV0FBVSxVQUFXOzs7OztPQUM3Qjs7Ozs7TUFDTDs7Ozs7O0lBRUo7Ozs7OztHQUdOLGNBQWMsYUFDYix3QkFBQyxrQkFBRDtJQUNFLFdBQVcsUUFBUTtJQUNuQixhQUFhLFFBQVE7SUFDckIsZUFBZSxRQUFRO0lBQ3ZCLGVBQWUsUUFBUTtJQUN2QixPQUFPLFFBQVE7SUFDZixjQUFjLFFBQVE7SUFDdEIsb0JBQW9CLFFBQVE7SUFDNUIsYUFBYSxRQUFRO0lBQ3JCLGFBQWEsU0FBUztLQUNwQixvQkFBb0IsSUFBSTtLQUN4QixhQUFhLE9BQU87SUFDdEI7R0FDRDs7Ozs7R0FHRixjQUFjLGFBQ2Isd0JBQUMsbUJBQUQ7SUFDRSxXQUFXLFFBQVE7SUFDbkIsYUFBYSxRQUFRO0dBQ3RCOzs7OztHQUlILHdCQUFDLGFBQUQ7SUFDRSxNQUFNO0lBQ04sY0FBYztJQUNkLGFBQWE7S0FDWCxJQUFJLFFBQVE7S0FDWixXQUFXLFFBQVE7S0FDbkIsT0FBTyxRQUFRLFNBQVM7S0FDeEIsT0FBTyxRQUFRLFNBQVM7S0FDeEIsaUJBQWlCLFFBQVEsbUJBQW1CO0tBQzVDLEtBQUssUUFBUSxPQUFPLFFBQVEsaUJBQWlCO0tBQzdDLFFBQVEsUUFBUSxVQUFVO0tBQzFCLGFBQWEsUUFBUSxlQUFlO0tBQ3BDLGFBQWEsUUFBUSxlQUFlO0tBQ3BDLGVBQWUsUUFBUSxpQkFBaUI7S0FDeEMsMEJBQTBCLFFBQVEsNEJBQTRCO0tBQzlELGNBQWMsUUFBUSxnQkFBZ0I7S0FDdEMsY0FBYyxRQUFRLGdCQUFnQjtLQUN0QyxvQkFBb0IsUUFBUSxzQkFBc0I7S0FDbEQsb0JBQW9CLFFBQVEsc0JBQXNCO0tBQ2xELGdCQUFnQixRQUFRLGdCQUFnQixTQUFTLEtBQUs7S0FDdEQsaUJBQWlCLFFBQVEsbUJBQW1CO0tBQzVDLGFBQWEsUUFBUSxlQUFlO0tBQ3BDLG1CQUFtQixRQUFRLHFCQUFxQjtLQUNoRCxPQUFPLFFBQVEsU0FBUztLQUN4QixZQUFZLFFBQVEsY0FBYztLQUNsQyxvQkFBb0IsUUFBUSxzQkFBc0I7S0FDbEQsa0JBQWtCLFFBQVEsb0JBQW9CO0tBQzlDLG9CQUFvQixRQUFRLHNCQUFzQjtJQUNwRDtHQUNEOzs7OztHQUVELHdCQUFDLDBCQUFEO0lBQ0UsTUFBTTtJQUNOLGNBQWM7SUFDZCxXQUFXO0lBQ1gsT0FBTTtJQUNOLGFBQVk7SUFDWixVQUFVLFFBQVE7SUFDTjtHQUNiOzs7OztFQUNFOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJwYXRpZW50LWRldGFpbHMtcGFnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZVJvdXRlUXVlcnlTdGF0ZSBhcyB1c2VRdWVyeVN0YXRlIH0gZnJvbSBcIkAvcm91dGVyL25hdmlnYXRpb25cIjtcbmltcG9ydCB7XG4gIEFycm93TGVmdCxcbiAgQ2FsZW5kYXIsXG4gIFBob25lLFxuICBNYWlsLFxuICBNYXBQaW4sXG4gIExvYWRlcjIsXG4gIFBlbmNpbCxcbiAgU2hpZWxkQWxlcnQsXG4gIEZpbGVUZXh0LFxuICBCcmllZmNhc2UsXG4gIENyZWRpdENhcmQsXG4gIFRyYXNoLFxuICBDaGV2cm9uTGVmdCxcbiAgQ2hldnJvblJpZ2h0LFxuICBDbGlwYm9hcmRDaGVjayxcbiAgQ2xvY2ssXG4gIFhDaXJjbGUsXG4gIENoZWNrQ2lyY2xlMixcbiAgSGlzdG9yeSxcbiAgTWludXNDaXJjbGUsXG4gIFByaW50ZXIsXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7XG4gIENhcmV0TGVmdCxcbiAgQ2FyZXRSaWdodCxcbiAgQ2FsZW5kYXJCbGFuayxcbiAgRnVubmVsLFxuICBDb2lucyxcbiAgRmlsZVBkZixcbiAgSWRlbnRpZmljYXRpb25DYXJkLFxuICBGaWxlcyxcbiAgTWFwVHJpZm9sZCxcbn0gZnJvbSBcIkBwaG9zcGhvci1pY29ucy9yZWFjdFwiO1xuaW1wb3J0IHsgdXNlUXVlcnksIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xuaW1wb3J0IHsgc3VwYWJhc2UgfSBmcm9tIFwiQC9saWIvc3VwYWJhc2VcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCI7XG5pbXBvcnQgeyBjbiwgZm9ybWF0UGhvbmVOdW1iZXIgfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcbmltcG9ydCB7IHVzZVBlcm1pc3Npb25zIH0gZnJvbSBcIkAvaG9va3MvdXNlUGVybWlzc2lvbnNcIjtcbmltcG9ydCB7IFBhdGllbnRGb3JtIH0gZnJvbSBcIkAvY29tcG9uZW50cy9mb3Jtcy9wYXRpZW50LWZvcm1cIjtcbmltcG9ydCB7IERvY3VtZW50TWFuYWdlciB9IGZyb20gXCJAL2NvbXBvbmVudHMvZG9jdW1lbnQtbWFuYWdlclwiO1xuaW1wb3J0IHsgRGVsZXRlQ29uZmlybWF0aW9uRGlhbG9nIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9kZWxldGUtY29uZmlybWF0aW9uLWRpYWxvZ1wiO1xuaW1wb3J0IHsgdXNlT25ib2FyZGluZyB9IGZyb20gXCJAL2NvbnRleHRzL09uYm9hcmRpbmdDb250ZXh0XCI7XG5pbXBvcnQgeyBQYXRpZW50Q3JlZGl0VGFiIH0gZnJvbSBcIkAvY29tcG9uZW50cy9jcmVkaXRzL1BhdGllbnRDcmVkaXRUYWJcIjtcbmltcG9ydCB0eXBlIHsgVHJpcCwgVHJpcFN0YXR1cyB9IGZyb20gXCJAL2NvbXBvbmVudHMvdHJpcHMvdHlwZXNcIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiQC9jb250ZXh0cy9hdXRoLWNvbnRleHRcIjtcbmltcG9ydCB7IHVzZU9yZ2FuaXphdGlvbiB9IGZyb20gXCJAL2NvbnRleHRzL09yZ2FuaXphdGlvbkNvbnRleHRcIjtcbmltcG9ydCB7IFBhdGllbnRTdW1tYXJ5VGFiIH0gZnJvbSBcIkAvY29tcG9uZW50cy9zdW1tYXJ5L1BhdGllbnRTdW1tYXJ5VGFiXCI7XG5pbXBvcnQge1xuICBnZXRBY3RpdmVUaW1lem9uZSxcbiAgZm9ybWF0SW5Vc2VyVGltZXpvbmUsXG4gIHBhcnNlWm9uZWRUaW1lLFxufSBmcm9tIFwiQC9saWIvdGltZXpvbmVcIjtcbmltcG9ydCB7IGdlbmVyYXRlUHJvZmlsZVBERiB9IGZyb20gXCJAL3V0aWxzL3Byb2ZpbGUtcGRmLWdlbmVyYXRvclwiO1xuaW1wb3J0IHsgdXNlQ2FuTWFuYWdlVXNlckFjY2VzcyB9IGZyb20gXCJAL2hvb2tzL3VzZUNhbk1hbmFnZVVzZXJBY2Nlc3NcIjtcbmltcG9ydCB7XG4gIEFjY2Vzc1N0YXR1c0JhZGdlLFxuICBVc2VyQWNjZXNzVG9nZ2xlQnV0dG9uLFxufSBmcm9tIFwiQC9jb21wb25lbnRzL3VzZXItYWNjZXNzLWNvbnRyb2xcIjtcblxuaW50ZXJmYWNlIFBhdGllbnREZXRhaWxzUGFnZVByb3BzIHtcbiAgaWQ6IHN0cmluZztcbiAgb25CYWNrOiAoKSA9PiB2b2lkO1xuICBvblRyaXBDbGljaz86IChpZDogc3RyaW5nKSA9PiB2b2lkO1xufVxuXG5pbnRlcmZhY2UgUGF0aWVudCB7XG4gIGlkOiBzdHJpbmc7XG4gIG9yZ19pZDogc3RyaW5nO1xuICBmdWxsX25hbWU6IHN0cmluZztcbiAgZGF0ZV9vZl9iaXJ0aDogc3RyaW5nIHwgbnVsbDtcbiAgZG9iOiBzdHJpbmcgfCBudWxsO1xuICBwaG9uZTogc3RyaW5nIHwgbnVsbDtcbiAgZW1haWw6IHN0cmluZyB8IG51bGw7XG4gIHByaW1hcnlfYWRkcmVzczogc3RyaW5nIHwgbnVsbDtcbiAgY291bnR5OiBzdHJpbmcgfCBudWxsO1xuICB3YWl2ZXJfdHlwZTogc3RyaW5nIHwgbnVsbDtcbiAgcmVmZXJyYWxfYnk6IHN0cmluZyB8IG51bGw7XG4gIHJlZmVycmFsX2RhdGU6IHN0cmluZyB8IG51bGw7XG4gIHJlZmVycmFsX2V4cGlyYXRpb25fZGF0ZTogc3RyaW5nIHwgbnVsbDtcbiAgc2VydmljZV90eXBlOiBzdHJpbmcgfCBudWxsO1xuICBjYXNlX21hbmFnZXI6IHN0cmluZyB8IG51bGw7XG4gIGNhc2VfbWFuYWdlcl9waG9uZTogc3RyaW5nIHwgbnVsbDtcbiAgY2FzZV9tYW5hZ2VyX2VtYWlsOiBzdHJpbmcgfCBudWxsO1xuICBtb250aGx5X2NyZWRpdDogbnVtYmVyIHwgbnVsbDtcbiAgY3JlZGl0X3VzZWRfZm9yOiBzdHJpbmcgfCBudWxsO1xuICBtZWRpY2FpZF9pZDogc3RyaW5nIHwgbnVsbDtcbiAgdmVoaWNsZV90eXBlX25lZWQ6IHN0cmluZyB8IG51bGw7XG4gIG5vdGVzOiBzdHJpbmcgfCBudWxsO1xuICBjcmVhdGVkX2F0OiBzdHJpbmc7XG4gIHNhbF9zdGF0dXM6IHN0cmluZyB8IG51bGw7XG4gIHNhbF9lZmZlY3RpdmVfZGF0ZTogc3RyaW5nIHwgbnVsbDtcbiAgc2FsX3Rocm91Z2hfZGF0ZTogc3RyaW5nIHwgbnVsbDtcbiAgc2FsX3BlbmRpbmdfcmVhc29uOiBzdHJpbmcgfCBudWxsO1xuICB1c2VyX2lkOiBzdHJpbmcgfCBudWxsO1xuICBkaXNhYmxlZDogYm9vbGVhbjtcbiAgZGlzYWJsZWRfYXQ6IHN0cmluZyB8IG51bGw7XG4gIGRpc2FibGVkX2J5OiBzdHJpbmcgfCBudWxsO1xufVxuXG5pbnRlcmZhY2UgU2FsSGlzdG9yeUVudHJ5IHtcbiAgaWQ6IHN0cmluZztcbiAgc3RhdHVzOiBzdHJpbmc7XG4gIGVmZmVjdGl2ZV9kYXRlOiBzdHJpbmcgfCBudWxsO1xuICB0aHJvdWdoX2RhdGU6IHN0cmluZyB8IG51bGw7XG4gIHBlbmRpbmdfcmVhc29uOiBzdHJpbmcgfCBudWxsO1xuICBjaGFuZ2VkX2J5X25hbWU6IHN0cmluZyB8IG51bGw7XG4gIGNyZWF0ZWRfYXQ6IHN0cmluZztcbiAgbm90ZXM6IHN0cmluZyB8IG51bGw7XG59XG5cbmNvbnN0IHN0YXR1c0NvbG9yczogUmVjb3JkPFRyaXBTdGF0dXMsIHN0cmluZz4gPSB7XG4gIHBlbmRpbmc6IFwiYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNzAwIGJvcmRlci1zbGF0ZS0yMDBcIixcbiAgYXNzaWduZWQ6IFwiYmctYmx1ZS01MCB0ZXh0LWJsdWUtNzAwIGJvcmRlci1ibHVlLTEwMFwiLFxuICBhY2NlcHRlZDogXCJiZy1pbmRpZ28tNTAgdGV4dC1pbmRpZ28tNzAwIGJvcmRlci1pbmRpZ28tMTAwXCIsXG4gIGVuX3JvdXRlOiBcImJnLXNreS01MCB0ZXh0LXNreS03MDAgYm9yZGVyLXNreS0xMDBcIixcbiAgYXJyaXZlZDogXCJiZy1hbWJlci01MCB0ZXh0LWFtYmVyLTcwMCBib3JkZXItYW1iZXItMTAwXCIsXG4gIGluX3Byb2dyZXNzOiBcImJnLWJsdWUtMTAwIHRleHQtYmx1ZS04MDAgYm9yZGVyLWJsdWUtMjAwXCIsXG4gIGNvbXBsZXRlZDogXCJiZy1lbWVyYWxkLTUwIHRleHQtZW1lcmFsZC03MDAgYm9yZGVyLWVtZXJhbGQtMTAwXCIsXG4gIGNhbmNlbGxlZDogXCJiZy1yZWQtNTAgdGV4dC1yZWQtNzAwIGJvcmRlci1yZWQtMTAwXCIsXG4gIG5vX3Nob3c6IFwiYmctb3JhbmdlLTUwIHRleHQtb3JhbmdlLTcwMCBib3JkZXItb3JhbmdlLTEwMFwiLFxuICB3YWl0aW5nOiBcImJnLWFtYmVyLTEwMCB0ZXh0LWFtYmVyLTgwMCBib3JkZXItYW1iZXItMjAwXCIsXG4gIGxvYWRlZDogXCJiZy1wdXJwbGUtNTAgdGV4dC1wdXJwbGUtNzAwIGJvcmRlci1wdXJwbGUtMTAwXCIsXG4gIGluX3BpY2t1cF9jaXJjbGU6IFwiYmctY3lhbi01MCB0ZXh0LWN5YW4tNzAwIGJvcmRlci1jeWFuLTEwMFwiLFxuICBpbl9kcm9wb2ZmX2NpcmNsZTogXCJiZy1waW5rLTUwIHRleHQtcGluay03MDAgYm9yZGVyLXBpbmstMTAwXCIsXG59O1xuXG5mdW5jdGlvbiBmb3JtYXREYXRlKGRhdGVTdHI6IHN0cmluZyB8IG51bGwsIHRpbWV6b25lOiBzdHJpbmcgPSBcIlVUQ1wiKSB7XG4gIGlmICghZGF0ZVN0cikgcmV0dXJuIFwiTm90IHNwZWNpZmllZFwiO1xuXG4gIC8vIEhhbmRsZSBZWVlZLU1NLUREIHNwZWNpZmljYWxseSAoQmlydGhkYXlzLCBldGMpXG4gIGlmIChcbiAgICBkYXRlU3RyLmxlbmd0aCA9PT0gMTAgJiZcbiAgICBkYXRlU3RyLmluY2x1ZGVzKFwiLVwiKSAmJlxuICAgICFkYXRlU3RyLmluY2x1ZGVzKFwiVFwiKVxuICApIHtcbiAgICByZXR1cm4gZm9ybWF0SW5Vc2VyVGltZXpvbmUoZGF0ZVN0ciwgXCJVVENcIiwgXCJNTU1NIGQsIHl5eXlcIik7XG4gIH1cblxuICByZXR1cm4gZm9ybWF0SW5Vc2VyVGltZXpvbmUoZGF0ZVN0ciwgdGltZXpvbmUsIFwiTU1NTSBkLCB5eXl5XCIpO1xufVxuXG5jb25zdCBUUklQU19QRVJfUEFHRSA9IDY7XG5cbmV4cG9ydCBmdW5jdGlvbiBQYXRpZW50RGV0YWlsc1BhZ2Uoe1xuICBpZCxcbiAgb25CYWNrLFxuICBvblRyaXBDbGljayxcbn06IFBhdGllbnREZXRhaWxzUGFnZVByb3BzKSB7XG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VRdWVyeVN0YXRlPFxuICAgIFwib3ZlcnZpZXdcIiB8IFwiZG9jdW1lbnRzXCIgfCBcInRyaXBzXCIgfCBcImNyZWRpdHNcIiB8IFwic3VtbWFyeVwiXG4gID4oXCJzZWN0aW9uXCIsIHtcbiAgICBkZWZhdWx0VmFsdWU6IFwib3ZlcnZpZXdcIixcbiAgICBwYXJzZTogKHZhbHVlKSA9PlxuICAgICAgKHZhbHVlIGFzIFwib3ZlcnZpZXdcIiB8IFwiZG9jdW1lbnRzXCIgfCBcInRyaXBzXCIgfCBcImNyZWRpdHNcIiB8IFwic3VtbWFyeVwiKSB8fFxuICAgICAgXCJvdmVydmlld1wiLFxuICB9KTtcbiAgY29uc3QgW2lzRWRpdGluZywgc2V0SXNFZGl0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3Nob3dEZWxldGVEaWFsb2csIHNldFNob3dEZWxldGVEaWFsb2ddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaXNEZWxldGluZywgc2V0SXNEZWxldGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IHsgcHJvZmlsZSB9ID0gdXNlQXV0aCgpO1xuICBjb25zdCB7IGN1cnJlbnRPcmdhbml6YXRpb24gfSA9IHVzZU9yZ2FuaXphdGlvbigpO1xuICBjb25zdCB7IGNhbkVkaXRQYXRpZW50cywgY2FuRGVsZXRlUGF0aWVudHMgfSA9IHVzZVBlcm1pc3Npb25zKCk7XG4gIGNvbnN0IHsgaXNEZW1vTW9kZSB9ID0gdXNlT25ib2FyZGluZygpO1xuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCk7XG4gIGNvbnN0IGNhbk1hbmFnZVVzZXJBY2Nlc3MgPSB1c2VDYW5NYW5hZ2VVc2VyQWNjZXNzKCk7XG5cbiAgY29uc3QgYWN0aXZlVGltZXpvbmUgPSB1c2VNZW1vKFxuICAgICgpID0+IGdldEFjdGl2ZVRpbWV6b25lKHByb2ZpbGUsIGN1cnJlbnRPcmdhbml6YXRpb24pLFxuICAgIFtwcm9maWxlLCBjdXJyZW50T3JnYW5pemF0aW9uXSxcbiAgKTtcblxuICAvLyBUcmlwIGhpc3RvcnkgZmlsdGVyaW5nIGFuZCBwYWdpbmF0aW9uIHN0YXRlXG4gIGNvbnN0IFt0cmlwTW9udGgsIHNldFRyaXBNb250aF0gPSB1c2VTdGF0ZSgoKSA9PiB7XG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcbiAgICByZXR1cm4gbmV3IERhdGUobm93LmdldEZ1bGxZZWFyKCksIG5vdy5nZXRNb250aCgpLCAxKTtcbiAgfSk7XG4gIGNvbnN0IFt0cmlwUGFnZSwgc2V0VHJpcFBhZ2VdID0gdXNlU3RhdGUoMSk7XG4gIGNvbnN0IFt0cmlwU3RhdHVzRmlsdGVyLCBzZXRUcmlwU3RhdHVzRmlsdGVyXSA9IHVzZVN0YXRlPFRyaXBTdGF0dXMgfCBcImFsbFwiPihcbiAgICBcImFsbFwiLFxuICApO1xuICBjb25zdCBbc2VsZWN0ZWRUcmlwRGF0ZSwgc2V0U2VsZWN0ZWRUcmlwRGF0ZV0gPSB1c2VRdWVyeVN0YXRlKFwiZGF0ZVwiLCB7XG4gICAgcGFyc2U6ICh2KSA9PiAodiA/IG5ldyBEYXRlKHYpIDogbnVsbCksXG4gICAgc2VyaWFsaXplOiAodikgPT4gdj8udG9JU09TdHJpbmcoKSA/PyBcIlwiLFxuICB9KTtcblxuICBjb25zdCBjYW5NYW5hZ2VQYXRpZW50cyA9IGNhbkVkaXRQYXRpZW50cyB8fCBjYW5EZWxldGVQYXRpZW50cztcblxuICAvLyBGZXRjaCBwYXRpZW50IGRhdGFcbiAgY29uc3QgeyBkYXRhOiBwYXRpZW50LCBpc0xvYWRpbmc6IGlzTG9hZGluZ1BhdGllbnQgfSA9IHVzZVF1ZXJ5KHtcbiAgICBxdWVyeUtleTogW1wicGF0aWVudFwiLCBpZF0sXG4gICAgcXVlcnlGbjogYXN5bmMgKCkgPT4ge1xuICAgICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJwYXRpZW50c1wiKVxuICAgICAgICAuc2VsZWN0KFwiKlwiKVxuICAgICAgICAuZXEoXCJpZFwiLCBpZClcbiAgICAgICAgLnNpbmdsZSgpO1xuXG4gICAgICBpZiAoZXJyb3IpIHRocm93IGVycm9yO1xuICAgICAgcmV0dXJuIGRhdGEgYXMgUGF0aWVudDtcbiAgICB9LFxuICAgIGVuYWJsZWQ6ICEhaWQsXG4gIH0pO1xuXG4gIC8vIEZldGNoIFNBTCBoaXN0b3J5XG4gIGNvbnN0IHsgZGF0YTogc2FsSGlzdG9yeSA9IFtdIH0gPSB1c2VRdWVyeSh7XG4gICAgcXVlcnlLZXk6IFtcInNhbC1oaXN0b3J5XCIsIGlkXSxcbiAgICBxdWVyeUZuOiBhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInBhdGllbnRfc2FsX2hpc3RvcnlcIilcbiAgICAgICAgLnNlbGVjdChcIipcIilcbiAgICAgICAgLmVxKFwicGF0aWVudF9pZFwiLCBpZClcbiAgICAgICAgLm9yZGVyKFwiY3JlYXRlZF9hdFwiLCB7IGFzY2VuZGluZzogZmFsc2UgfSk7XG4gICAgICBpZiAoZXJyb3IpIHRocm93IGVycm9yO1xuICAgICAgcmV0dXJuIGRhdGEgYXMgU2FsSGlzdG9yeUVudHJ5W107XG4gICAgfSxcbiAgICBlbmFibGVkOiAhIWlkLFxuICB9KTtcblxuICAvLyBGZXRjaCBhbGwgdHJpcHMgZm9yIHRoaXMgcGF0aWVudFxuICBjb25zdCB7IGRhdGE6IGFsbFRyaXBzID0gW10sIGlzTG9hZGluZzogaXNMb2FkaW5nVHJpcHMgfSA9IHVzZVF1ZXJ5KHtcbiAgICBxdWVyeUtleTogW1wicGF0aWVudC10cmlwc1wiLCBpZF0sXG4gICAgcXVlcnlGbjogYXN5bmMgKCkgPT4ge1xuICAgICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJ0cmlwc1wiKVxuICAgICAgICAuc2VsZWN0KFxuICAgICAgICAgIGBcbiAgICAgICAgICAqLFxuICAgICAgICAgIGRyaXZlcjpkcml2ZXJzKGlkLCBmdWxsX25hbWUsIHBob25lLCB2ZWhpY2xlX2luZm8pXG4gICAgICAgIGAsXG4gICAgICAgIClcbiAgICAgICAgLmVxKFwicGF0aWVudF9pZFwiLCBpZClcbiAgICAgICAgLm9yZGVyKFwicGlja3VwX3RpbWVcIiwgeyBhc2NlbmRpbmc6IGZhbHNlIH0pO1xuXG4gICAgICBpZiAoZXJyb3IpIHRocm93IGVycm9yO1xuICAgICAgcmV0dXJuIGRhdGEgYXMgVHJpcFtdO1xuICAgIH0sXG4gICAgZW5hYmxlZDogISFpZCxcbiAgfSk7XG5cbiAgLy8gRmV0Y2ggZG9jdW1lbnQgY291bnRcbiAgY29uc3QgeyBkYXRhOiBkb2NDb3VudCA9IDAgfSA9IHVzZVF1ZXJ5KHtcbiAgICBxdWVyeUtleTogW1wicGF0aWVudC1kb2NzLWNvdW50XCIsIGlkXSxcbiAgICBxdWVyeUZuOiBhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCB7IGNvdW50LCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJvcmdfdXBsb2Fkc1wiKVxuICAgICAgICAuc2VsZWN0KFwiKlwiLCB7IGNvdW50OiBcImV4YWN0XCIsIGhlYWQ6IHRydWUgfSlcbiAgICAgICAgLmVxKFwicHVycG9zZVwiLCBcInBhdGllbnRfZG9jdW1lbnRcIilcbiAgICAgICAgLmVxKFwibm90ZXNcIiwgaWQpO1xuICAgICAgaWYgKGVycm9yKSB0aHJvdyBlcnJvcjtcbiAgICAgIHJldHVybiBjb3VudCB8fCAwO1xuICAgIH0sXG4gIH0pO1xuXG4gIC8vIEZpbHRlciB0cmlwcyBieSBtb250aCBhbmQgc3RhdHVzXG4gIGNvbnN0IGZpbHRlcmVkVHJpcHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICAvLyBJZiBhIHNwZWNpZmljIGRhdGUgaXMgc2VsZWN0ZWQsIGZpbHRlciBieSB0aGF0IGRheVxuICAgIGlmIChzZWxlY3RlZFRyaXBEYXRlKSB7XG4gICAgICBjb25zdCB0YXJnZXREYXRlU3RyID0gZm9ybWF0SW5Vc2VyVGltZXpvbmUoXG4gICAgICAgIHNlbGVjdGVkVHJpcERhdGUsXG4gICAgICAgIGFjdGl2ZVRpbWV6b25lLFxuICAgICAgICBcInl5eXktTU0tZGRcIixcbiAgICAgICk7XG4gICAgICByZXR1cm4gYWxsVHJpcHMuZmlsdGVyKCh0cmlwKSA9PiB7XG4gICAgICAgIGNvbnN0IHRyaXBEYXRlU3RyID0gZm9ybWF0SW5Vc2VyVGltZXpvbmUoXG4gICAgICAgICAgdHJpcC5waWNrdXBfdGltZSxcbiAgICAgICAgICBhY3RpdmVUaW1lem9uZSxcbiAgICAgICAgICBcInl5eXktTU0tZGRcIixcbiAgICAgICAgKTtcbiAgICAgICAgY29uc3QgbWF0Y2hlc1N0YXR1cyA9XG4gICAgICAgICAgdHJpcFN0YXR1c0ZpbHRlciA9PT0gXCJhbGxcIiB8fCB0cmlwLnN0YXR1cyA9PT0gdHJpcFN0YXR1c0ZpbHRlcjtcbiAgICAgICAgcmV0dXJuIHRyaXBEYXRlU3RyID09PSB0YXJnZXREYXRlU3RyICYmIG1hdGNoZXNTdGF0dXM7XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyBPdGhlcndpc2Ugc2hvdyBhbGwgdHJpcHMgZm9yIHRoZSBzZWxlY3RlZCBtb250aFxuICAgIGNvbnN0IG1vbnRoU3RyID0gZm9ybWF0SW5Vc2VyVGltZXpvbmUodHJpcE1vbnRoLCBhY3RpdmVUaW1lem9uZSwgXCJ5eXl5LU1NXCIpO1xuICAgIGNvbnN0IHN0YXJ0T2ZNb250aFVUQyA9IHBhcnNlWm9uZWRUaW1lKFxuICAgICAgYCR7bW9udGhTdHJ9LTAxYCxcbiAgICAgIFwiMDA6MDBcIixcbiAgICAgIGFjdGl2ZVRpbWV6b25lLFxuICAgICk7XG5cbiAgICAvLyBHZXQgbGFzdCBkYXkgb2YgbW9udGhcbiAgICBjb25zdCB5ZWFyID0gcGFyc2VJbnQobW9udGhTdHIuc3BsaXQoXCItXCIpWzBdKTtcbiAgICBjb25zdCBtb250aCA9IHBhcnNlSW50KG1vbnRoU3RyLnNwbGl0KFwiLVwiKVsxXSk7XG4gICAgY29uc3QgbGFzdERheSA9IG5ldyBEYXRlKHllYXIsIG1vbnRoLCAwKS5nZXREYXRlKCk7XG4gICAgY29uc3QgZW5kT2ZNb250aFVUQyA9IHBhcnNlWm9uZWRUaW1lKFxuICAgICAgYCR7bW9udGhTdHJ9LSR7bGFzdERheX1gLFxuICAgICAgXCIyMzo1OTo1OVwiLFxuICAgICAgYWN0aXZlVGltZXpvbmUsXG4gICAgKTtcblxuICAgIHJldHVybiBhbGxUcmlwcy5maWx0ZXIoKHRyaXApID0+IHtcbiAgICAgIGNvbnN0IHRyaXBEYXRlID0gbmV3IERhdGUodHJpcC5waWNrdXBfdGltZSk7XG4gICAgICBjb25zdCBpbk1vbnRoID0gdHJpcERhdGUgPj0gc3RhcnRPZk1vbnRoVVRDICYmIHRyaXBEYXRlIDw9IGVuZE9mTW9udGhVVEM7XG4gICAgICBjb25zdCBtYXRjaGVzU3RhdHVzID1cbiAgICAgICAgdHJpcFN0YXR1c0ZpbHRlciA9PT0gXCJhbGxcIiB8fCB0cmlwLnN0YXR1cyA9PT0gdHJpcFN0YXR1c0ZpbHRlcjtcbiAgICAgIHJldHVybiBpbk1vbnRoICYmIG1hdGNoZXNTdGF0dXM7XG4gICAgfSk7XG4gIH0sIFthbGxUcmlwcywgdHJpcE1vbnRoLCB0cmlwU3RhdHVzRmlsdGVyLCBzZWxlY3RlZFRyaXBEYXRlLCBhY3RpdmVUaW1lem9uZV0pO1xuXG4gIC8vIFBhZ2luYXRlIGZpbHRlcmVkIHRyaXBzXG4gIGNvbnN0IHBhZ2luYXRlZFRyaXBzID0gdXNlTWVtbygoKSA9PiB7XG4gICAgY29uc3Qgc3RhcnQgPSAodHJpcFBhZ2UgLSAxKSAqIFRSSVBTX1BFUl9QQUdFO1xuICAgIHJldHVybiBmaWx0ZXJlZFRyaXBzLnNsaWNlKHN0YXJ0LCBzdGFydCArIFRSSVBTX1BFUl9QQUdFKTtcbiAgfSwgW2ZpbHRlcmVkVHJpcHMsIHRyaXBQYWdlXSk7XG5cbiAgY29uc3QgdG90YWxUcmlwUGFnZXMgPSBNYXRoLmNlaWwoZmlsdGVyZWRUcmlwcy5sZW5ndGggLyBUUklQU19QRVJfUEFHRSk7XG5cbiAgLy8gUmVzZXQgdG8gcGFnZSAxIHdoZW4gZmlsdGVycyBjaGFuZ2VcbiAgdXNlTWVtbygoKSA9PiB7XG4gICAgc2V0VHJpcFBhZ2UoMSk7XG4gIH0sIFt0cmlwTW9udGgsIHRyaXBTdGF0dXNGaWx0ZXIsIHNlbGVjdGVkVHJpcERhdGVdKTtcblxuICBjb25zdCBnb1RvUHJldk1vbnRoID0gKCkgPT4ge1xuICAgIHNldFRyaXBNb250aChcbiAgICAgIChwcmV2KSA9PiBuZXcgRGF0ZShwcmV2LmdldEZ1bGxZZWFyKCksIHByZXYuZ2V0TW9udGgoKSAtIDEsIDEpLFxuICAgICk7XG4gIH07XG5cbiAgY29uc3QgZ29Ub05leHRNb250aCA9ICgpID0+IHtcbiAgICBzZXRUcmlwTW9udGgoXG4gICAgICAocHJldikgPT4gbmV3IERhdGUocHJldi5nZXRGdWxsWWVhcigpLCBwcmV2LmdldE1vbnRoKCkgKyAxLCAxKSxcbiAgICApO1xuICB9O1xuXG4gIGNvbnN0IGdvVG9DdXJyZW50TW9udGggPSAoKSA9PiB7XG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcbiAgICBzZXRUcmlwTW9udGgobmV3IERhdGUobm93LmdldEZ1bGxZZWFyKCksIG5vdy5nZXRNb250aCgpLCAxKSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmIChpc0RlbW9Nb2RlKSByZXR1cm47XG4gICAgc2V0SXNEZWxldGluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbShcInBhdGllbnRzXCIpLmRlbGV0ZSgpLmVxKFwiaWRcIiwgaWQpO1xuICAgICAgaWYgKGVycm9yKSB0aHJvdyBlcnJvcjtcbiAgICAgIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcInBhdGllbnRzXCJdIH0pO1xuICAgICAgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoe1xuICAgICAgICBxdWVyeUtleTogW1widHJpcHNcIiwgXCJkaXJlY3RvcnktY291bnRzXCIsIGN1cnJlbnRPcmdhbml6YXRpb24/LmlkXSxcbiAgICAgIH0pO1xuICAgICAgb25CYWNrKCk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGRlbGV0ZSBwYXRpZW50OlwiLCBlcnIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0RlbGV0aW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgaWYgKGlzTG9hZGluZ1BhdGllbnQpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtOTYgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cImgtOCB3LTggYW5pbWF0ZS1zcGluIHRleHQtc2xhdGUtNDAwXCIgLz5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICBpZiAoIXBhdGllbnQpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMlwiPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMFwiPlBhdGllbnQgbm90IGZvdW5kPC9wPlxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJsaW5rXCIgb25DbGljaz17b25CYWNrfT5cbiAgICAgICAgICBHbyBiYWNrIHRvIHBhdGllbnRzXG4gICAgICAgIDwvQnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIGNvbnN0IGFjY2Vzc0Rpc2FibGVkID0gcGF0aWVudC5kaXNhYmxlZCA9PT0gdHJ1ZTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICB7LyogSGVhZGVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00IDJ4bDpmbGV4LXJvdyAyeGw6aXRlbXMtY2VudGVyIDJ4bDpqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi13LTAgaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25CYWNrfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQtbGcgaG92ZXI6Ymctc2xhdGUtMTAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8QXJyb3dMZWZ0IHNpemU9ezIwfSBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMFwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwibWluLXctMCBicmVhay13b3JkcyB0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwXCI+XG4gICAgICAgICAgICAgIHtwYXRpZW50LmZ1bGxfbmFtZX1cbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMiBtdC0xXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LW1lZGl1bSBiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgICBDbGllbnQgUHJvZmlsZVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxBY2Nlc3NTdGF0dXNCYWRnZSBkaXNhYmxlZD17YWNjZXNzRGlzYWJsZWR9IC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICBJRDoge3BhdGllbnQuaWQuc3Vic3RyaW5nKDAsIDgpfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIHctZnVsbCBncmlkLWNvbHMtMSBnYXAtMiBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyAyeGw6ZmxleCAyeGw6dy1hdXRvIDJ4bDpmbGV4LXdyYXAgMnhsOmp1c3RpZnktZW5kXCI+XG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT5cbiAgICAgICAgICAgICAgZ2VuZXJhdGVQcm9maWxlUERGKFxuICAgICAgICAgICAgICAgIFwicGF0aWVudFwiLFxuICAgICAgICAgICAgICAgIHBhdGllbnQsXG4gICAgICAgICAgICAgICAgY3VycmVudE9yZ2FuaXphdGlvbj8ubmFtZSB8fCBcIlwiLFxuICAgICAgICAgICAgICAgIGFjdGl2ZVRpbWV6b25lLFxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHJvdW5kZWQteGwgMnhsOnctYXV0b1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFByaW50ZXIgc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgICBQcmludCBPdXRcbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICB7KGNhbk1hbmFnZVBhdGllbnRzIHx8IGNhbk1hbmFnZVVzZXJBY2Nlc3MpICYmIChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIHtjYW5FZGl0UGF0aWVudHMgJiYgKFxuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzRWRpdGluZyh0cnVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcm91bmRlZC14bCAyeGw6dy1hdXRvXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8UGVuY2lsIHNpemU9ezE2fSAvPlxuICAgICAgICAgICAgICAgICAgRWRpdCBEZXRhaWxzXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDxVc2VyQWNjZXNzVG9nZ2xlQnV0dG9uXG4gICAgICAgICAgICAgICAgdGFyZ2V0VHlwZT1cInBhdGllbnRcIlxuICAgICAgICAgICAgICAgIHJlY29yZElkPXtwYXRpZW50LmlkfVxuICAgICAgICAgICAgICAgIHN1YmplY3ROYW1lPXtwYXRpZW50LmZ1bGxfbmFtZX1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17YWNjZXNzRGlzYWJsZWR9XG4gICAgICAgICAgICAgICAgY2FuTWFuYWdlPXtjYW5NYW5hZ2VVc2VyQWNjZXNzfVxuICAgICAgICAgICAgICAgIGlzRGVtb01vZGU9e2lzRGVtb01vZGV9XG4gICAgICAgICAgICAgICAgb25TdWNjZXNzPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbXCJwYXRpZW50XCIsIGlkXSB9KTtcbiAgICAgICAgICAgICAgICAgIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHtcbiAgICAgICAgICAgICAgICAgICAgcXVlcnlLZXk6IFtcInBhdGllbnRzXCIsIGN1cnJlbnRPcmdhbml6YXRpb24/LmlkXSxcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIHtjYW5EZWxldGVQYXRpZW50cyAmJiAoXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0RlbGV0ZURpYWxvZyh0cnVlKX1cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0RlbW9Nb2RlfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIHRleHQtcmVkLTYwMCBib3JkZXItcmVkLTEwMCBob3ZlcjpiZy1yZWQtNTAgaG92ZXI6dGV4dC1yZWQtNzAwIDJ4bDp3LWF1dG9cIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxUcmFzaCBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICAgIERlbGV0ZSBQYXRpZW50XG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogTmF2aWdhdGlvbiBUYWJzICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYi0wIHNtOmJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgLW14LTQgcHgtNCBzbTpteC0wIHNtOnB4LTBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIgc206Z2FwLTBcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoXCJvdmVydmlld1wiKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgIFwicHgtNCBweS0yIHNtOnB5LTMgdGV4dC1zbSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWFsbCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB3aGl0ZXNwYWNlLW5vd3JhcCByb3VuZGVkLXhsIHNtOnJvdW5kZWQtbm9uZSBzbTpib3JkZXItYi0yXCIsXG4gICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gXCJvdmVydmlld1wiXG4gICAgICAgICAgICAgICAgPyBcImJnLVsjM0Q1QTNEXS8xMCB0ZXh0LVsjM0Q1QTNEXSBzbTpiZy10cmFuc3BhcmVudCBzbTpib3JkZXItWyMzRDVBM0RdXCJcbiAgICAgICAgICAgICAgICA6IFwidGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC1zbGF0ZS03MDAgaG92ZXI6Ymctc2xhdGUtMTAwIHNtOmhvdmVyOmJnLXRyYW5zcGFyZW50IHNtOmJvcmRlci10cmFuc3BhcmVudCBzbTpob3Zlcjpib3JkZXItc2xhdGUtMzAwXCIsXG4gICAgICAgICAgICApfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxJZGVudGlmaWNhdGlvbkNhcmRcbiAgICAgICAgICAgICAgc2l6ZT17MTZ9XG4gICAgICAgICAgICAgIHdlaWdodD1cImR1b3RvbmVcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsjM0Q1QTNEXVwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgT3ZlcnZpZXdcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoXCJkb2N1bWVudHNcIil9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICBcInB4LTQgcHktMiBzbTpweS0zIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgd2hpdGVzcGFjZS1ub3dyYXAgcm91bmRlZC14bCBzbTpyb3VuZGVkLW5vbmUgc206Ym9yZGVyLWItMlwiLFxuICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09IFwiZG9jdW1lbnRzXCJcbiAgICAgICAgICAgICAgICA/IFwiYmctWyMzRDVBM0RdLzEwIHRleHQtWyMzRDVBM0RdIHNtOmJnLXRyYW5zcGFyZW50IHNtOmJvcmRlci1bIzNENUEzRF1cIlxuICAgICAgICAgICAgICAgIDogXCJ0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXNsYXRlLTcwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgc206aG92ZXI6YmctdHJhbnNwYXJlbnQgc206Ym9yZGVyLXRyYW5zcGFyZW50IHNtOmhvdmVyOmJvcmRlci1zbGF0ZS0zMDBcIixcbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEZpbGVzIHNpemU9ezE2fSB3ZWlnaHQ9XCJkdW90b25lXCIgY2xhc3NOYW1lPVwidGV4dC1bIzNENUEzRF1cIiAvPlxuICAgICAgICAgICAgRG9jdW1lbnRzXG4gICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgIFwicHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQtWzEwcHhdIGZvbnQtYm9sZFwiLFxuICAgICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gXCJkb2N1bWVudHNcIlxuICAgICAgICAgICAgICAgICAgPyBcImJnLVsjM0Q1QTNEXSB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgIDogXCJiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS01MDBcIixcbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2RvY0NvdW50fVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYihcInRyaXBzXCIpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgXCJweC00IHB5LTIgc206cHktMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHdoaXRlc3BhY2Utbm93cmFwIHJvdW5kZWQteGwgc206cm91bmRlZC1ub25lIHNtOmJvcmRlci1iLTJcIixcbiAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSBcInRyaXBzXCJcbiAgICAgICAgICAgICAgICA/IFwiYmctWyMzRDVBM0RdLzEwIHRleHQtWyMzRDVBM0RdIHNtOmJnLXRyYW5zcGFyZW50IHNtOmJvcmRlci1bIzNENUEzRF1cIlxuICAgICAgICAgICAgICAgIDogXCJ0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXNsYXRlLTcwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgc206aG92ZXI6YmctdHJhbnNwYXJlbnQgc206Ym9yZGVyLXRyYW5zcGFyZW50IHNtOmhvdmVyOmJvcmRlci1zbGF0ZS0zMDBcIixcbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPE1hcFRyaWZvbGQgc2l6ZT17MTZ9IHdlaWdodD1cImR1b3RvbmVcIiBjbGFzc05hbWU9XCJ0ZXh0LVsjM0Q1QTNEXVwiIC8+XG4gICAgICAgICAgICBUcmlwIEhpc3RvcnlcbiAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgXCJweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gZm9udC1ib2xkXCIsXG4gICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSBcInRyaXBzXCJcbiAgICAgICAgICAgICAgICAgID8gXCJiZy1bIzNENUEzRF0gdGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICA6IFwiYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNTAwXCIsXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHthbGxUcmlwcy5sZW5ndGh9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgey8qIENyZWRpdHMgVGFiIC0gc2hvdyBmb3IgYWRtaW5zL293bmVycyBvciBpZiBwYXRpZW50IGhhcyBjcmVkaXQgKi99XG4gICAgICAgICAgeyhjYW5NYW5hZ2VQYXRpZW50cyB8fCBwYXRpZW50Lm1vbnRobHlfY3JlZGl0KSAmJiAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYihcImNyZWRpdHNcIil9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgXCJweC00IHB5LTIgc206cHktMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHdoaXRlc3BhY2Utbm93cmFwIHJvdW5kZWQteGwgc206cm91bmRlZC1ub25lIHNtOmJvcmRlci1iLTJcIixcbiAgICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09IFwiY3JlZGl0c1wiXG4gICAgICAgICAgICAgICAgICA/IFwiYmctWyMzRDVBM0RdLzEwIHRleHQtWyMzRDVBM0RdIHNtOmJnLXRyYW5zcGFyZW50IHNtOmJvcmRlci1bIzNENUEzRF1cIlxuICAgICAgICAgICAgICAgICAgOiBcInRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGhvdmVyOmJnLXNsYXRlLTEwMCBzbTpob3ZlcjpiZy10cmFuc3BhcmVudCBzbTpib3JkZXItdHJhbnNwYXJlbnQgc206aG92ZXI6Ym9yZGVyLXNsYXRlLTMwMFwiLFxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8Q29pbnMgd2VpZ2h0PVwiZHVvdG9uZVwiIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LVsjM0Q1QTNEXVwiIC8+XG4gICAgICAgICAgICAgIENyZWRpdHNcbiAgICAgICAgICAgICAge3BhdGllbnQubW9udGhseV9jcmVkaXQgJiYgKFxuICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICBcInB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxMHB4XSBmb250LWJvbGRcIixcbiAgICAgICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSBcImNyZWRpdHNcIlxuICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1bIzNENUEzRF0gdGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWVtZXJhbGQtMTAwIHRleHQtZW1lcmFsZC03MDBcIixcbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgJHtwYXRpZW50Lm1vbnRobHlfY3JlZGl0LnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKX1cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoXCJzdW1tYXJ5XCIpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgXCJweC00IHB5LTIgc206cHktMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHdoaXRlc3BhY2Utbm93cmFwIHJvdW5kZWQteGwgc206cm91bmRlZC1ub25lIHNtOmJvcmRlci1iLTJcIixcbiAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSBcInN1bW1hcnlcIlxuICAgICAgICAgICAgICAgID8gXCJiZy1bIzNENUEzRF0vMTAgdGV4dC1bIzNENUEzRF0gc206YmctdHJhbnNwYXJlbnQgc206Ym9yZGVyLVsjM0Q1QTNEXVwiXG4gICAgICAgICAgICAgICAgOiBcInRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGhvdmVyOmJnLXNsYXRlLTEwMCBzbTpob3ZlcjpiZy10cmFuc3BhcmVudCBzbTpib3JkZXItdHJhbnNwYXJlbnQgc206aG92ZXI6Ym9yZGVyLXNsYXRlLTMwMFwiLFxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8RmlsZVBkZiBzaXplPXsxNn0gd2VpZ2h0PVwiZHVvdG9uZVwiIGNsYXNzTmFtZT1cInRleHQtWyMzRDVBM0RdXCIgLz5cbiAgICAgICAgICAgIFRyaXBzIHN1bW1hcnlcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFRhYiBDb250ZW50ICovfVxuICAgICAge2FjdGl2ZVRhYiA9PT0gXCJvdmVydmlld1wiICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0zIGdhcC02XCI+XG4gICAgICAgICAgey8qIE1haW4gQ29udGVudCBBcmVhICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tMiBzcGFjZS15LTZcIj5cbiAgICAgICAgICAgIHsvKiBQZXJzb25hbCBJbmZvcm1hdGlvbiAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcC02IHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwIG1iLTZcIj5cbiAgICAgICAgICAgICAgICBQZXJzb25hbCBJbmZvcm1hdGlvblxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLThcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLXNsYXRlLTUwIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXNsYXRlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBEYXRlIG9mIEJpcnRoXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtOTAwIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdERhdGUocGF0aWVudC5kYXRlX29mX2JpcnRoLCBhY3RpdmVUaW1lem9uZSl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLXNsYXRlLTUwIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8UGhvbmUgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXNsYXRlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBQaG9uZSBOdW1iZXJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS05MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7cGF0aWVudC5waG9uZVxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IGZvcm1hdFBob25lTnVtYmVyKHBhdGllbnQucGhvbmUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJOb3Qgc3BlY2lmaWVkXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLXNsYXRlLTUwIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8TWFwUGluIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1zbGF0ZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgUHJpbWFyeSBBZGRyZXNzXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtOTAwIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3BhdGllbnQucHJpbWFyeV9hZGRyZXNzIHx8IFwiTm90IHNwZWNpZmllZFwifVxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLXNsYXRlLTUwIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8TWFpbCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtc2xhdGUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIEVtYWlsIEFkZHJlc3NcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS05MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7cGF0aWVudC5lbWFpbCB8fCBcIk5vdCBzcGVjaWZpZWRcIn1cbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctc2xhdGUtNTAgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxNYXBQaW4gY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXNsYXRlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBDb3VudHlcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS05MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7cGF0aWVudC5jb3VudHkgfHwgXCJOb3Qgc3BlY2lmaWVkXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogU2VydmljZSAmIFJlZmVycmFsIEluZm9ybWF0aW9uICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBwLTYgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgbWItNlwiPlxuICAgICAgICAgICAgICAgIFNlcnZpY2UgJiBSZWZlcnJhbFxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLThcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICBTZXJ2aWNlIFR5cGVcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTkwMCBtdC0xIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3BhdGllbnQuc2VydmljZV90eXBlIHx8IFwiTm90IHNwZWNpZmllZFwifVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgV2FpdmVyIFR5cGVcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTkwMCBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3BhdGllbnQud2FpdmVyX3R5cGUgfHwgXCJOb3Qgc3BlY2lmaWVkXCJ9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICBWZWhpY2xlIE5lZWRcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTkwMCBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3BhdGllbnQudmVoaWNsZV90eXBlX25lZWQgfHwgXCJOb3Qgc3BlY2lmaWVkXCJ9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgIFJlZmVycmVkIEJ5XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS05MDAgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtwYXRpZW50LnJlZmVycmFsX2J5IHx8IFwiTm90IHNwZWNpZmllZFwifVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgUmVmZXJyYWwgUGVyaW9kXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS05MDAgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtwYXRpZW50LnJlZmVycmFsX2RhdGVcbiAgICAgICAgICAgICAgICAgICAgICAgID8gZm9ybWF0RGF0ZShwYXRpZW50LnJlZmVycmFsX2RhdGUsIGFjdGl2ZVRpbWV6b25lKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlN0YXJ0XCJ9XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXgtMiB0ZXh0LXNsYXRlLTQwMFwiPuKGkjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICB7cGF0aWVudC5yZWZlcnJhbF9leHBpcmF0aW9uX2RhdGVcbiAgICAgICAgICAgICAgICAgICAgICAgID8gZm9ybWF0RGF0ZShcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXRpZW50LnJlZmVycmFsX2V4cGlyYXRpb25fZGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVUaW1lem9uZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcIkVuZFwifVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIENhc2UgTWFuYWdlbWVudCAmIEJpbGxpbmcgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTZcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBwLTYgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItNCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPEJyaWVmY2FzZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIENhc2UgTWFuYWdlbWVudFxuICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5NYW5hZ2VyIE5hbWU8L3A+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7cGF0aWVudC5jYXNlX21hbmFnZXIgfHwgXCJOb25lIGFzc2lnbmVkXCJ9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPkNvbnRhY3QgTnVtYmVyPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3BhdGllbnQuY2FzZV9tYW5hZ2VyX3Bob25lXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGZvcm1hdFBob25lTnVtYmVyKHBhdGllbnQuY2FzZV9tYW5hZ2VyX3Bob25lKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcIk4vQVwifVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5FbWFpbDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtwYXRpZW50LmNhc2VfbWFuYWdlcl9lbWFpbCB8fCBcIk4vQVwifVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcC02IHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxDcmVkaXRDYXJkIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1zbGF0ZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgQmlsbGluZyBEZXRhaWxzXG4gICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPk1vbnRobHkgQ3JlZGl0PC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3BhdGllbnQubW9udGhseV9jcmVkaXRcbiAgICAgICAgICAgICAgICAgICAgICAgID8gYCQke3BhdGllbnQubW9udGhseV9jcmVkaXQudG9GaXhlZCgyKX1gXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiJDAuMDBcIn1cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+Q3JlZGl0IFVzZWQgRm9yPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3BhdGllbnQuY3JlZGl0X3VzZWRfZm9yIHx8IFwiR2VuZXJhbCB1c2VcIn1cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+TWVkaWNhaWQgSUQ8L3A+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS05MDAgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3BhdGllbnQubWVkaWNhaWRfaWQgfHwgXCJOL0FcIn1cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBNZWRpY2FsIE5vdGVzICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBwLTYgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTZcIj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwXCI+XG4gICAgICAgICAgICAgICAgICBNZWRpY2FsIE5vdGVzXG4gICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICA8RmlsZVRleHQgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXNsYXRlLTMwMFwiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1zbGF0ZS01MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMTAwIG1pbi1oLVsxMjBweF1cIj5cbiAgICAgICAgICAgICAgICB7cGF0aWVudC5ub3RlcyA/IChcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIGxlYWRpbmctcmVsYXhlZCB3aGl0ZXNwYWNlLXByZS13cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgIHtwYXRpZW50Lm5vdGVzfVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBpdGFsaWNcIj5cbiAgICAgICAgICAgICAgICAgICAgTm8gbm90ZXMgcmVjb3JkZWQgZm9yIHRoaXMgcGF0aWVudC5cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFNpZGViYXIgLSBQYXRpZW50IFN0YXR1cyBtZXJnZWQgaW50byBvdmVydmlldyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBwLTYgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTRcIj5cbiAgICAgICAgICAgICAgICBQYXRpZW50IFN0YXR1c1xuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB5LTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTUwXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNTAwXCI+VG90YWwgVHJpcHM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAge2FsbFRyaXBzLmxlbmd0aH1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweS0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS01MFwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTUwMFwiPkxhc3QgVHJhbnNwb3J0PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7YWxsVHJpcHMubGVuZ3RoID4gMFxuICAgICAgICAgICAgICAgICAgICAgID8gZm9ybWF0RGF0ZShhbGxUcmlwc1swXS5waWNrdXBfdGltZSwgYWN0aXZlVGltZXpvbmUpXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIk5ldmVyXCJ9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHktMlwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTUwMFwiPkFkZGVkIE9uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0RGF0ZShwYXRpZW50LmNyZWF0ZWRfYXQsIGFjdGl2ZVRpbWV6b25lKX1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFNBTCBTdGF0dXMgQ2FyZCAqL31cbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICBcInJvdW5kZWQtMnhsIGJvcmRlciBwLTYgc2hhZG93LXNtXCIsXG4gICAgICAgICAgICAgICAgcGF0aWVudC5zYWxfc3RhdHVzID09PSBcImFwcHJvdmVkXCIgJiZcbiAgICAgICAgICAgICAgICAgIFwiYmctZW1lcmFsZC01MC81MCBib3JkZXItZW1lcmFsZC0yMDBcIixcbiAgICAgICAgICAgICAgICBwYXRpZW50LnNhbF9zdGF0dXMgPT09IFwicGVuZGluZ1wiICYmXG4gICAgICAgICAgICAgICAgICBcImJnLWFtYmVyLTUwLzUwIGJvcmRlci1hbWJlci0yMDBcIixcbiAgICAgICAgICAgICAgICBwYXRpZW50LnNhbF9zdGF0dXMgPT09IFwiZXhwaXJlZFwiICYmXG4gICAgICAgICAgICAgICAgICBcImJnLXJlZC01MC81MCBib3JkZXItcmVkLTIwMFwiLFxuICAgICAgICAgICAgICAgICFwYXRpZW50LnNhbF9zdGF0dXMgJiYgXCJiZy13aGl0ZSBib3JkZXItc2xhdGUtMjAwXCIsXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8Q2xpcGJvYXJkQ2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNsYXRlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgU0FMIFN0YXR1c1xuICAgICAgICAgICAgICA8L2gzPlxuXG4gICAgICAgICAgICAgIHsvKiBDdXJyZW50IFN0YXR1cyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICB7cGF0aWVudC5zYWxfc3RhdHVzID09PSBcImFwcHJvdmVkXCIgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZW1lcmFsZC03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgQXBwcm92ZWRcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtwYXRpZW50LnNhbF9lZmZlY3RpdmVfZGF0ZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0RGF0ZShcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhdGllbnQuc2FsX2VmZmVjdGl2ZV9kYXRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aXZlVGltZXpvbmUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJteC0xXCI+4oaSPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwYXRpZW50LnNhbF90aHJvdWdoX2RhdGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gZm9ybWF0RGF0ZShcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXRpZW50LnNhbF90aHJvdWdoX2RhdGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aXZlVGltZXpvbmUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJObyBlbmQgZGF0ZVwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICB7cGF0aWVudC5zYWxfc3RhdHVzID09PSBcInBlbmRpbmdcIiAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1hbWJlci0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtYW1iZXItNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBlbmRpbmdcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtwYXRpZW50LnNhbF9wZW5kaW5nX3JlYXNvbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgbGluZS1jbGFtcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3BhdGllbnQuc2FsX3BlbmRpbmdfcmVhc29ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICB7cGF0aWVudC5zYWxfc3RhdHVzID09PSBcImV4cGlyZWRcIiAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1yZWQtMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8WENpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcmVkLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXJlZC02MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgRXhwaXJlZFxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICBOZWVkcyByZWNlcnRpZmljYXRpb25cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAge3BhdGllbnQuc2FsX3N0YXR1cyA9PT0gXCJuL2FcIiAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxNaW51c0NpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIE4vQVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICBOb3QgYXBwbGljYWJsZSB0byB0aGlzIGNsaWVudFxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICB7IXBhdGllbnQuc2FsX3N0YXR1cyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDbGlwYm9hcmRDaGVjayBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICBOb3QgU2V0XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIE5vIFNBTCBzdGF0dXMgcmVjb3JkZWRcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIFNBTCBIaXN0b3J5IFRpbWVsaW5lICovfVxuICAgICAgICAgICAgICAgIHtzYWxIaXN0b3J5Lmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIHB0LTMgbXQtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgbWItMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxIaXN0b3J5IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICBIaXN0b3J5ICh7c2FsSGlzdG9yeS5sZW5ndGh9KVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjUgbWF4LWgtWzIwMHB4XSBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2FsSGlzdG9yeS5tYXAoKGVudHJ5KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17ZW50cnkuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZW50cnkuc3RhdHVzID09PSBcImFwcHJvdmVkXCIgJiYgXCJiZy1lbWVyYWxkLTUwLzcwXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZW50cnkuc3RhdHVzID09PSBcInBlbmRpbmdcIiAmJiBcImJnLWFtYmVyLTUwLzcwXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZW50cnkuc3RhdHVzID09PSBcImV4cGlyZWRcIiAmJiBcImJnLXJlZC01MC83MFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVudHJ5LnN0YXR1cyA9PT0gXCJuL2FcIiAmJiBcImJnLXNsYXRlLTUwXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ3LTUgaC01IHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaHJpbmstMCBtdC0wLjVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVudHJ5LnN0YXR1cyA9PT0gXCJhcHByb3ZlZFwiICYmIFwiYmctZW1lcmFsZC0xMDBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVudHJ5LnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIgJiYgXCJiZy1hbWJlci0xMDBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVudHJ5LnN0YXR1cyA9PT0gXCJleHBpcmVkXCIgJiYgXCJiZy1yZWQtMTAwXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbnRyeS5zdGF0dXMgPT09IFwibi9hXCIgJiYgXCJiZy1zbGF0ZS0yMDBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2VudHJ5LnN0YXR1cyA9PT0gXCJhcHByb3ZlZFwiICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWVtZXJhbGQtNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlbnRyeS5zdGF0dXMgPT09IFwicGVuZGluZ1wiICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTMgaC0zIHRleHQtYW1iZXItNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlbnRyeS5zdGF0dXMgPT09IFwiZXhwaXJlZFwiICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxYQ2lyY2xlIGNsYXNzTmFtZT1cInctMyBoLTMgdGV4dC1yZWQtNTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlbnRyeS5zdGF0dXMgPT09IFwibi9hXCIgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1pbnVzQ2lyY2xlIGNsYXNzTmFtZT1cInctMyBoLTMgdGV4dC1zbGF0ZS01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJmb250LXNlbWlib2xkIGNhcGl0YWxpemVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbnRyeS5zdGF0dXMgPT09IFwiYXBwcm92ZWRcIiAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ0ZXh0LWVtZXJhbGQtNzAwXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW50cnkuc3RhdHVzID09PSBcInBlbmRpbmdcIiAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ0ZXh0LWFtYmVyLTcwMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVudHJ5LnN0YXR1cyA9PT0gXCJleHBpcmVkXCIgJiYgXCJ0ZXh0LXJlZC02MDBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbnRyeS5zdGF0dXMgPT09IFwibi9hXCIgJiYgXCJ0ZXh0LXNsYXRlLTYwMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZW50cnkuc3RhdHVzID09PSBcIm4vYVwiID8gXCJOL0FcIiA6IGVudHJ5LnN0YXR1c31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShlbnRyeS5jcmVhdGVkX2F0KS50b0xvY2FsZURhdGVTdHJpbmcoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbi1VU1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vbnRoOiBcInNob3J0XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXk6IFwibnVtZXJpY1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeWVhcjogXCIyLWRpZ2l0XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZW50cnkuc3RhdHVzID09PSBcImFwcHJvdmVkXCIgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVudHJ5LmVmZmVjdGl2ZV9kYXRlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbnRyeS5lZmZlY3RpdmVfZGF0ZSArIFwiVDAwOjAwOjAwXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1VU1wiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb250aDogXCJzaG9ydFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF5OiBcIm51bWVyaWNcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJteC0xXCI+4oaSPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlbnRyeS50aHJvdWdoX2RhdGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gbmV3IERhdGUoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW50cnkudGhyb3VnaF9kYXRlICsgXCJUMDA6MDA6MDBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1VU1wiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9udGg6IFwic2hvcnRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXk6IFwibnVtZXJpY1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIuKAlFwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlbnRyeS5zdGF0dXMgPT09IFwicGVuZGluZ1wiICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbnRyeS5wZW5kaW5nX3JlYXNvbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGxpbmUtY2xhbXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlbnRyeS5wZW5kaW5nX3JlYXNvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7IWNhbk1hbmFnZVBhdGllbnRzICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1hbWJlci01MCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCByb3VuZGVkLTJ4bCBwLTZcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRleHQtYW1iZXItODAwIG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxTaGllbGRBbGVydCBzaXplPXsyMH0gLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5WaWV3IE9ubHk8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWFtYmVyLTcwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgIFlvdSBoYXZlIHZpZXctb25seSBhY2Nlc3MgdG8gdGhpcyBwYXRpZW50J3MgcHJvZmlsZS4gT25seVxuICAgICAgICAgICAgICAgICAgYWRtaW5pc3RyYXRvcnMgYW5kIG93bmVycyBjYW4gbW9kaWZ5IGRldGFpbHMgb3IgdXBsb2FkXG4gICAgICAgICAgICAgICAgICBkb2N1bWVudHMuXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAge2FjdGl2ZVRhYiA9PT0gXCJkb2N1bWVudHNcIiAmJiAoXG4gICAgICAgIDxEb2N1bWVudE1hbmFnZXJcbiAgICAgICAgICBvd25lcklkPXtpZH1cbiAgICAgICAgICBwdXJwb3NlPVwicGF0aWVudF9kb2N1bWVudFwiXG4gICAgICAgICAgc291cmNlPVwicGF0aWVudHNcIlxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAge2FjdGl2ZVRhYiA9PT0gXCJ0cmlwc1wiICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICB7LyogVHJpcCBGaWx0ZXJzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBwLTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICAgICAgICAgIHsvKiBNb250aCBOYXZpZ2F0aW9uIC0gSGlkZSB3aGVuIGZpbHRlcmluZyBieSBzcGVjaWZpYyBkYXkgKi99XG4gICAgICAgICAgICAgIHshc2VsZWN0ZWRUcmlwRGF0ZSA/IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2dvVG9QcmV2TW9udGh9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOCB3LTggcC0wXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPENhcmV0TGVmdCBzaXplPXsxNn0gd2VpZ2h0PVwiYm9sZFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtnb1RvQ3VycmVudE1vbnRofVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggcHgtMyB0ZXh0LXhzIGZvbnQtbWVkaXVtIG1pbi13LVsxNDBweF1cIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8Q2FsZW5kYXJCbGFua1xuICAgICAgICAgICAgICAgICAgICAgIHNpemU9ezE0fVxuICAgICAgICAgICAgICAgICAgICAgIHdlaWdodD1cImR1b3RvbmVcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1yLTJcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0SW5Vc2VyVGltZXpvbmUoXG4gICAgICAgICAgICAgICAgICAgICAgdHJpcE1vbnRoLFxuICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZVRpbWV6b25lLFxuICAgICAgICAgICAgICAgICAgICAgIFwiTU1NTSB5eXl5XCIsXG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17Z29Ub05leHRNb250aH1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IHctOCBwLTBcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8Q2FyZXRSaWdodCBzaXplPXsxNn0gd2VpZ2h0PVwiYm9sZFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS05MDAgYmctc2xhdGUtMTAwIHB4LTMgcHktMS41IHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPENhbGVuZGFyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1zbGF0ZS01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0SW5Vc2VyVGltZXpvbmUoXG4gICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRUcmlwRGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVUaW1lem9uZSxcbiAgICAgICAgICAgICAgICAgICAgICBcIk1NTU0gZCwgeXl5eVwiLFxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkVHJpcERhdGUobnVsbCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOCBweC0zIHRleHQteHMgaG92ZXI6Ymctc2xhdGUtMTAwIHRleHQtc2xhdGUtNTAwXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgU2hvdyBhbGxcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHsvKiBTdGF0dXMgRmlsdGVyICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPEZ1bm5lbCBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt0cmlwU3RhdHVzRmlsdGVyfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxuICAgICAgICAgICAgICAgICAgICBzZXRUcmlwU3RhdHVzRmlsdGVyKGUudGFyZ2V0LnZhbHVlIGFzIFRyaXBTdGF0dXMgfCBcImFsbFwiKVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgcHgtMyB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzNENUEzRF0vMjBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhbGxcIj5BbGwgU3RhdHVzPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwicGVuZGluZ1wiPlBlbmRpbmc8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhc3NpZ25lZFwiPkFzc2lnbmVkPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiaW5fcHJvZ3Jlc3NcIj5JbiBQcm9ncmVzczwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNvbXBsZXRlZFwiPkNvbXBsZXRlZDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNhbmNlbGxlZFwiPkNhbmNlbGxlZDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZFRyaXBzLmxlbmd0aH0gdHJpcFxuICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkVHJpcHMubGVuZ3RoICE9PSAxID8gXCJzXCIgOiBcIlwifVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBUcmlwIENhcmRzICovfVxuICAgICAgICAgIHtpc0xvYWRpbmdUcmlwcyA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTQ4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJoLTggdy04IGFuaW1hdGUtc3BpbiB0ZXh0LXNsYXRlLTQwMFwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogcGFnaW5hdGVkVHJpcHMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTEyIGJnLXdoaXRlIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZGFzaGVkIGJvcmRlci1zbGF0ZS0zMDAgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTEyIGgtMTIgcm91bmRlZC1mdWxsIGJnLXNsYXRlLTUwIGJvcmRlciBib3JkZXItc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICAgICAgPENhbGVuZGFyIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1zbGF0ZS0zMDBcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPlxuICAgICAgICAgICAgICAgICAgTm8gdHJpcHMgZm91bmRcbiAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgIE5vIHRyaXBzIHNjaGVkdWxlZCBmb3J7XCIgXCJ9XG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRUcmlwRGF0ZVxuICAgICAgICAgICAgICAgICAgICA/IGZvcm1hdEluVXNlclRpbWV6b25lKFxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRUcmlwRGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZVRpbWV6b25lLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJNTU1NIGQsIHl5eXlcIixcbiAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgIDogZm9ybWF0SW5Vc2VyVGltZXpvbmUoXG4gICAgICAgICAgICAgICAgICAgICAgICB0cmlwTW9udGgsXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVUaW1lem9uZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiTU1NTSB5eXl5XCIsXG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIHt0cmlwU3RhdHVzRmlsdGVyICE9PSBcImFsbFwiXG4gICAgICAgICAgICAgICAgICAgID8gYCB3aXRoIHN0YXR1cyBcIiR7dHJpcFN0YXR1c0ZpbHRlci5yZXBsYWNlKFwiX1wiLCBcIiBcIil9XCJgXG4gICAgICAgICAgICAgICAgICAgIDogXCJcIn1cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyBnYXAtNFwiPlxuICAgICAgICAgICAgICB7cGFnaW5hdGVkVHJpcHMubWFwKCh0cmlwKSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAga2V5PXt0cmlwLmlkfVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25UcmlwQ2xpY2s/Lih0cmlwLmlkKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIGJnLXdoaXRlIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBvdmVyZmxvdy1oaWRkZW4gZmxleCBmbGV4LWNvbFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgey8qIFN0YXR1cyBIZWFkZXIgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBib3JkZXItYiBib3JkZXItc2xhdGUtNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICAgIFwicHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LXNlbWlib2xkIGJvcmRlclwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzQ29sb3JzW3RyaXAuc3RhdHVzXSxcbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge3RyaXAuc3RhdHVzLnJlcGxhY2UoXCJfXCIsIFwiIFwiKS50b1VwcGVyQ2FzZSgpfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7dHJpcC50cmlwX3R5cGV9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSBzcGFjZS15LTQgZmxleC0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbGF0ZS02MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEluVXNlclRpbWV6b25lKFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0cmlwLnBpY2t1cF90aW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVUaW1lem9uZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJNTU0gZCwgeXl5eVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgKX17XCIgXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICBhdHtcIiBcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRJblVzZXJUaW1lem9uZShcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHJpcC5waWNrdXBfdGltZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aXZlVGltZXpvbmUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiaDptbSBhXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIExvY2F0aW9ucyAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTIgdGV4dC1zbGF0ZS02MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxNYXBQaW4gY2xhc3NOYW1lPVwidy00IGgtNCBtdC0wLjUgZmxleC1zaHJpbmstMCB0ZXh0LXJlZC00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBsaW5lLWNsYW1wLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3RyaXAucGlja3VwX2xvY2F0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMiB0ZXh0LXNsYXRlLTYwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPE1hcFBpbiBjbGFzc05hbWU9XCJ3LTQgaC00IG10LTAuNSBmbGV4LXNocmluay0wIHRleHQtZW1lcmFsZC00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBsaW5lLWNsYW1wLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3RyaXAuZHJvcG9mZl9sb2NhdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIERyaXZlciAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS01MCB0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgRHJpdmVyOiB7dHJpcC5kcml2ZXI/LmZ1bGxfbmFtZSB8fCBcIlVuYXNzaWduZWRcIn1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIFBhZ2luYXRpb24gKi99XG4gICAgICAgICAge3RvdGFsVHJpcFBhZ2VzID4gMSAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHB0LTRcIj5cbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRyaXBQYWdlKChwKSA9PiBNYXRoLm1heCgxLCBwIC0gMSkpfVxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXt0cmlwUGFnZSA9PT0gMX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggdy04IHAtMFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8Q2hldnJvbkxlZnQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNjAwIHB4LTJcIj5cbiAgICAgICAgICAgICAgICBQYWdlIHt0cmlwUGFnZX0gb2Yge3RvdGFsVHJpcFBhZ2VzfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxuICAgICAgICAgICAgICAgICAgc2V0VHJpcFBhZ2UoKHApID0+IE1hdGgubWluKHRvdGFsVHJpcFBhZ2VzLCBwICsgMSkpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXt0cmlwUGFnZSA9PT0gdG90YWxUcmlwUGFnZXN9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IHctOCBwLTBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHthY3RpdmVUYWIgPT09IFwiY3JlZGl0c1wiICYmIChcbiAgICAgICAgPFBhdGllbnRDcmVkaXRUYWJcbiAgICAgICAgICBwYXRpZW50SWQ9e3BhdGllbnQuaWR9XG4gICAgICAgICAgcGF0aWVudE5hbWU9e3BhdGllbnQuZnVsbF9uYW1lfVxuICAgICAgICAgIG1vbnRobHlDcmVkaXQ9e3BhdGllbnQubW9udGhseV9jcmVkaXR9XG4gICAgICAgICAgY3JlZGl0VXNlZEZvcj17cGF0aWVudC5jcmVkaXRfdXNlZF9mb3J9XG4gICAgICAgICAgbm90ZXM9e3BhdGllbnQubm90ZXN9XG4gICAgICAgICAgcmVmZXJyYWxEYXRlPXtwYXRpZW50LnJlZmVycmFsX2RhdGV9XG4gICAgICAgICAgcmVmZXJyYWxFeHBpcmF0aW9uPXtwYXRpZW50LnJlZmVycmFsX2V4cGlyYXRpb25fZGF0ZX1cbiAgICAgICAgICBzZXJ2aWNlVHlwZT17cGF0aWVudC5zZXJ2aWNlX3R5cGV9XG4gICAgICAgICAgb25EYXlDbGljaz17KGRhdGUpID0+IHtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkVHJpcERhdGUoZGF0ZSk7XG4gICAgICAgICAgICBzZXRBY3RpdmVUYWIoXCJ0cmlwc1wiKTtcbiAgICAgICAgICB9fVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAge2FjdGl2ZVRhYiA9PT0gXCJzdW1tYXJ5XCIgJiYgKFxuICAgICAgICA8UGF0aWVudFN1bW1hcnlUYWJcbiAgICAgICAgICBwYXRpZW50SWQ9e3BhdGllbnQuaWR9XG4gICAgICAgICAgcGF0aWVudE5hbWU9e3BhdGllbnQuZnVsbF9uYW1lfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAgey8qIEVkaXQgRm9ybSAqL31cbiAgICAgIDxQYXRpZW50Rm9ybVxuICAgICAgICBvcGVuPXtpc0VkaXRpbmd9XG4gICAgICAgIG9uT3BlbkNoYW5nZT17c2V0SXNFZGl0aW5nfVxuICAgICAgICBpbml0aWFsRGF0YT17e1xuICAgICAgICAgIGlkOiBwYXRpZW50LmlkLFxuICAgICAgICAgIGZ1bGxfbmFtZTogcGF0aWVudC5mdWxsX25hbWUsXG4gICAgICAgICAgZW1haWw6IHBhdGllbnQuZW1haWwgfHwgXCJcIixcbiAgICAgICAgICBwaG9uZTogcGF0aWVudC5waG9uZSB8fCBcIlwiLFxuICAgICAgICAgIHByaW1hcnlfYWRkcmVzczogcGF0aWVudC5wcmltYXJ5X2FkZHJlc3MgfHwgXCJcIixcbiAgICAgICAgICBkb2I6IHBhdGllbnQuZG9iIHx8IHBhdGllbnQuZGF0ZV9vZl9iaXJ0aCB8fCBcIlwiLFxuICAgICAgICAgIGNvdW50eTogcGF0aWVudC5jb3VudHkgfHwgXCJcIixcbiAgICAgICAgICB3YWl2ZXJfdHlwZTogcGF0aWVudC53YWl2ZXJfdHlwZSB8fCBcIlwiLFxuICAgICAgICAgIHJlZmVycmFsX2J5OiBwYXRpZW50LnJlZmVycmFsX2J5IHx8IFwiXCIsXG4gICAgICAgICAgcmVmZXJyYWxfZGF0ZTogcGF0aWVudC5yZWZlcnJhbF9kYXRlIHx8IFwiXCIsXG4gICAgICAgICAgcmVmZXJyYWxfZXhwaXJhdGlvbl9kYXRlOiBwYXRpZW50LnJlZmVycmFsX2V4cGlyYXRpb25fZGF0ZSB8fCBcIlwiLFxuICAgICAgICAgIHNlcnZpY2VfdHlwZTogcGF0aWVudC5zZXJ2aWNlX3R5cGUgfHwgXCJcIixcbiAgICAgICAgICBjYXNlX21hbmFnZXI6IHBhdGllbnQuY2FzZV9tYW5hZ2VyIHx8IFwiXCIsXG4gICAgICAgICAgY2FzZV9tYW5hZ2VyX3Bob25lOiBwYXRpZW50LmNhc2VfbWFuYWdlcl9waG9uZSB8fCBcIlwiLFxuICAgICAgICAgIGNhc2VfbWFuYWdlcl9lbWFpbDogcGF0aWVudC5jYXNlX21hbmFnZXJfZW1haWwgfHwgXCJcIixcbiAgICAgICAgICBtb250aGx5X2NyZWRpdDogcGF0aWVudC5tb250aGx5X2NyZWRpdD8udG9TdHJpbmcoKSB8fCBcIlwiLFxuICAgICAgICAgIGNyZWRpdF91c2VkX2ZvcjogcGF0aWVudC5jcmVkaXRfdXNlZF9mb3IgfHwgXCJcIixcbiAgICAgICAgICBtZWRpY2FpZF9pZDogcGF0aWVudC5tZWRpY2FpZF9pZCB8fCBcIlwiLFxuICAgICAgICAgIHZlaGljbGVfdHlwZV9uZWVkOiBwYXRpZW50LnZlaGljbGVfdHlwZV9uZWVkIHx8IFwiXCIsXG4gICAgICAgICAgbm90ZXM6IHBhdGllbnQubm90ZXMgfHwgXCJcIixcbiAgICAgICAgICBzYWxfc3RhdHVzOiBwYXRpZW50LnNhbF9zdGF0dXMgfHwgXCJcIixcbiAgICAgICAgICBzYWxfZWZmZWN0aXZlX2RhdGU6IHBhdGllbnQuc2FsX2VmZmVjdGl2ZV9kYXRlIHx8IFwiXCIsXG4gICAgICAgICAgc2FsX3Rocm91Z2hfZGF0ZTogcGF0aWVudC5zYWxfdGhyb3VnaF9kYXRlIHx8IFwiXCIsXG4gICAgICAgICAgc2FsX3BlbmRpbmdfcmVhc29uOiBwYXRpZW50LnNhbF9wZW5kaW5nX3JlYXNvbiB8fCBcIlwiLFxuICAgICAgICB9fVxuICAgICAgLz5cblxuICAgICAgPERlbGV0ZUNvbmZpcm1hdGlvbkRpYWxvZ1xuICAgICAgICBvcGVuPXtzaG93RGVsZXRlRGlhbG9nfVxuICAgICAgICBvbk9wZW5DaGFuZ2U9e3NldFNob3dEZWxldGVEaWFsb2d9XG4gICAgICAgIG9uQ29uZmlybT17aGFuZGxlRGVsZXRlfVxuICAgICAgICB0aXRsZT1cIkRlbGV0ZSBQYXRpZW50P1wiXG4gICAgICAgIGRlc2NyaXB0aW9uPVwiVGhpcyBhY3Rpb24gY2Fubm90IGJlIHVuZG9uZS4gVGhpcyB3aWxsIHBlcm1hbmVudGx5IGRlbGV0ZSB0aGUgcGF0aWVudCBhbmQgYWxsIGFzc29jaWF0ZWQgZGF0YVwiXG4gICAgICAgIGl0ZW1OYW1lPXtwYXRpZW50LmZ1bGxfbmFtZX1cbiAgICAgICAgaXNEZWxldGluZz17aXNEZWxldGluZ31cbiAgICAgIC8+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXX0=