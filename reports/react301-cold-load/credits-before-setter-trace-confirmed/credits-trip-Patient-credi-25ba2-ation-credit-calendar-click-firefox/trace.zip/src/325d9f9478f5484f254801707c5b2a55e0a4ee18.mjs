import { expect, test } from '@playwright/test';
import { writeFile } from 'node:fs/promises';
import { directoryRows, installDirectoryFixtures } from './fixtures.mjs';

test.use({ timezoneId: 'America/Chicago' });

const patient = { ...directoryRows.patients[0], monthly_credit: 300, notes: null, referral_date: null,
  referral_expiration_date: null, credit_used_for: 'Synthetic transport', service_type: 'Ambulatory' };
const trip = { id: '00000000-0000-4000-8000-000000009301', org_id: patient.org_id, patient_id: patient.id,
  pickup_time: '2026-10-02T15:00:00.000Z', status: 'completed', trip_type: 'One Way',
  pickup_location: 'Synthetic pickup', dropoff_location: 'Synthetic destination', distance_miles: 10,
  actual_distance_miles: 10, total_waiting_minutes: 0, billing_details: { service_type: 'Ambulatory' },
  driver: null, created_at: '2026-10-01T12:00:00.000Z' };

async function installCreditFixtures(context, page, baseURL) {
  const fixture = await installDirectoryFixtures(context, page, baseURL, { savedView: 'list' });
  await page.clock.install({ time: new Date('2026-10-14T12:00:00.000Z') });
  await page.route('**/rest/v1/**', async route => {
    const url = new URL(route.request().url());
    const table = url.pathname.split('/').at(-1);
    if (table === 'patients' && url.searchParams.get('id') === `eq.${patient.id}`) return route.fulfill({ json: patient });
    if (table === 'trips' && url.searchParams.get('patient_id') === `eq.${patient.id}`) return route.fulfill({ json: [trip] });
    return route.fallback();
  });
  await page.addInitScript(() => { window.__patientTripMemoCalls = []; });
  if (process.env.PATIENT_DETAILS_DIAGNOSTIC === '1') {
    await page.route(/\/src\/components\/patient-details-page\.tsx(?:\?.*)?$/, async route => {
      const response = await route.fetch();
      const body = await response.text();
      const instrumented = body.replace(/useMemo\(\(\) => \{\s*setTripPage\(1\);\s*\}, \[\s*tripMonth,\s*tripStatusFilter,\s*selectedTripDate\s*\]\);/, matched => matched.replace('setTripPage(1);', `window.__patientTripMemoCalls.push({ at: performance.now(), date: selectedTripDate?.toISOString() ?? null, sameDateIdentity: window.__previousTripDate === selectedTripDate, stack: new Error("Observed original patient details pagination memo setter").stack }); window.__previousTripDate = selectedTripDate; setTripPage(1);`));
      expect(instrumented, 'Response-only memo observation must match the original setter').not.toBe(body);
      await route.fulfill({ response, body: instrumented });
    });
  }
  return fixture;
}

for (const entry of ['credit calendar click', 'direct dated trip bookmark']) {
  test(`Patient credit trip navigation: ${entry}`, async ({ context, page, baseURL }, info) => {
    const fixture = await installCreditFixtures(context, page, baseURL);
    const dateQuery = '&date=2026-10-02T05%3A00%3A00.000Z';
    try {
      await page.goto(`/?page=patient-details&id=${patient.id}&section=${entry === 'credit calendar click' ? 'credits' : `trips${dateQuery}`}`);
      if (entry === 'credit calendar click') {
        await expect(page.getByText('Credit Overview', { exact: true })).toBeVisible();
        const dayWithSpend = page.locator('div.aspect-square.cursor-pointer').filter({ hasText: '$46' });
        await expect(dayWithSpend).toHaveCount(1);
        await dayWithSpend.click();
      }
      await expect(page.getByRole('button', { name: 'Show all', exact: true })).toBeVisible();
      await expect(page.getByText('Synthetic pickup', { exact: true })).toBeVisible();
      expect(new URL(page.url()).searchParams.get('section')).toBe('trips');
      expect(new URL(page.url()).searchParams.get('date')).toBe('2026-10-02T05:00:00.000Z');
      expect(fixture.errors).toEqual([]);
      expect(fixture.consoleErrors).toEqual([]);
    } finally {
      await writeFile(info.outputPath('credits-trip-evidence.json'), JSON.stringify({ synthetic: true, entry,
        mode: process.env.DIRECTORIES_DEV === '1' ? 'development StrictMode' : 'production preview',
        instrumentation: process.env.PATIENT_DETAILS_DIAGNOSTIC === '1' ? 'Observation before unchanged setter; no state or dependency change' : null,
        url: page.url(), errors: fixture.errors, consoleErrors: fixture.consoleErrors, diagnostics: await fixture.captureDiagnostics(),
        setterCalls: await page.evaluate(() => window.__patientTripMemoCalls), body: await page.locator('main').first().innerText(),
      }, null, 2));
    }
  });
}
